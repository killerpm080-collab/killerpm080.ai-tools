// Tool Types
export interface Tool {
  id: string;
  name: string;
  description: string;
  slug: string;
  category: string;
  icon: string;
  featured: boolean;
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  toolCount: number;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  tags: string[];
  featured: boolean;
}

export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  schema?: object;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'editor';
}

export interface Analytics {
  pageViews: number;
  uniqueVisitors: number;
  topTools: { toolId: string; views: number }[];
  topPages: { path: string; views: number }[];
}

export interface AdPlacement {
  id: string;
  name: string;
  location: 'header' | 'sidebar' | 'in-content' | 'footer';
  code: string;
  active: boolean;
}
