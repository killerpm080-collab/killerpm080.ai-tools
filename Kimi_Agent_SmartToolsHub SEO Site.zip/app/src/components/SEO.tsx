import { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  keywords?: string[];
  canonical?: string;
  ogImage?: string;
  ogType?: string;
  schema?: object | object[];
  noIndex?: boolean;
}

export function SEO({
  title,
  description,
  keywords = [],
  canonical,
  ogImage = 'https://smarttoolshub.com/og-image.jpg',
  ogType = 'website',
  schema,
  noIndex = false
}: SEOProps) {
  useEffect(() => {
    // Update document title
    document.title = title;

    // Update or create meta tags
    const metaTags = [
      { name: 'description', content: description },
      { name: 'keywords', content: keywords.join(', ') },
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:type', content: ogType },
      { property: 'og:image', content: ogImage },
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title },
      { name: 'twitter:description', content: description },
      { name: 'twitter:image', content: ogImage },
    ];

    // Add noindex if specified
    if (noIndex) {
      metaTags.push({ name: 'robots', content: 'noindex, nofollow' });
    } else {
      metaTags.push({ name: 'robots', content: 'index, follow' });
    }

    metaTags.forEach(({ name, property, content }) => {
      let meta: HTMLMetaElement | null = null;
      if (name) {
        meta = document.querySelector(`meta[name="${name}"]`);
        if (!meta) {
          meta = document.createElement('meta');
          meta.setAttribute('name', name);
          document.head.appendChild(meta);
        }
      } else if (property) {
        meta = document.querySelector(`meta[property="${property}"]`);
        if (!meta) {
          meta = document.createElement('meta');
          meta.setAttribute('property', property);
          document.head.appendChild(meta);
        }
      }
      if (meta) {
        meta.setAttribute('content', content);
      }
    });

    // Update canonical link
    if (canonical) {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonical);
    }

    // Add schema markup
    if (schema) {
      const schemas = Array.isArray(schema) ? schema : [schema];
      schemas.forEach((s, index) => {
        const scriptId = `schema-${index}`;
        let script = document.getElementById(scriptId) as HTMLScriptElement | null;
        if (!script) {
          script = document.createElement('script');
          script.id = scriptId;
          script.setAttribute('type', 'application/ld+json');
          document.head.appendChild(script);
        }
        script.textContent = JSON.stringify(s);
      });
    }

    // Cleanup function
    return () => {
      // Clean up schema scripts on unmount
      if (schema) {
        const schemas = Array.isArray(schema) ? schema : [schema];
        schemas.forEach((_, index) => {
          const scriptId = `schema-${index}`;
          const script = document.getElementById(scriptId);
          if (script) {
            script.remove();
          }
        });
      }
    };
  }, [title, description, keywords, canonical, ogImage, ogType, schema, noIndex]);

  return null;
}

export default SEO;
