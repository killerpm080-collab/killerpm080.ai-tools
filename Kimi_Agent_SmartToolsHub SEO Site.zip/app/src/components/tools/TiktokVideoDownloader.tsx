import { useState } from 'react';
import { Download, Link, AlertCircle, Video, ExternalLink, Info, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { isValidTikTokUrl, copyToClipboard } from '@/lib/utils';

interface VideoInfo {
  id: string;
  title: string;
  author: string;
  thumbnail: string;
  duration: string;
  downloadUrl: string;
}

export function TiktokVideoDownloader() {
  const [url, setUrl] = useState('');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setVideoInfo(null);
    
    if (!url.trim()) {
      setError('Please enter a TikTok URL');
      return;
    }

    if (!isValidTikTokUrl(url)) {
      setError('Please enter a valid TikTok URL');
      return;
    }

    setLoading(true);
    
    // Simulate API call - in production, this would call a backend service
    // Since TikTok's API requires authentication, this is a demo implementation
    setTimeout(() => {
      // Extract video ID from URL for demo purposes
      const videoId = url.split('/').pop()?.split('?')[0] || 'demo';
      
      setVideoInfo({
        id: videoId,
        title: 'TikTok Video',
        author: '@user',
        thumbnail: `https://placehold.co/600x800/000000/FFFFFF/png?text=TikTok+Video`,
        duration: '0:15',
        downloadUrl: '#'
      });
      setLoading(false);
    }, 1500);
  };

  const handleCopy = async () => {
    if (await copyToClipboard(url)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                TikTok Video URL
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Link className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="https://www.tiktok.com/@username/video/..."
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <><Video className="w-4 h-4 mr-2" /> Get Video</>
                  )}
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-500">
              Paste the TikTok video link from the app or website
            </p>
          </form>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Video Info */}
      {videoInfo && (
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Thumbnail */}
              <div className="aspect-[9/16] max-w-[300px] mx-auto bg-gray-100 rounded-lg overflow-hidden">
                <img
                  src={videoInfo.thumbnail}
                  alt="Video thumbnail"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Details */}
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">{videoInfo.title}</h3>
                  <p className="text-gray-600">by {videoInfo.author}</p>
                  <p className="text-sm text-gray-500">Duration: {videoInfo.duration}</p>
                </div>

                <Tabs defaultValue="download" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="download">Download</TabsTrigger>
                    <TabsTrigger value="info">Info</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="download" className="space-y-3">
                    <Button className="w-full" size="lg">
                      <Download className="w-5 h-5 mr-2" />
                      Download Video (No Watermark)
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Download className="w-5 h-5 mr-2" />
                      Download Audio Only (MP3)
                    </Button>
                  </TabsContent>
                  
                  <TabsContent value="info">
                    <div className="space-y-2 text-sm">
                      <p><strong>Video ID:</strong> {videoInfo.id}</p>
                      <p><strong>Format:</strong> MP4</p>
                      <p><strong>Quality:</strong> HD (1080p)</p>
                      <p><strong>Watermark:</strong> Removed</p>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={handleCopy}>
                    {copied ? <><Check className="w-4 h-4 mr-2" /> Copied!</> : <><Copy className="w-4 h-4 mr-2" /> Copy Link</>}
                  </Button>
                  <Button variant="outline" className="flex-1" asChild>
                    <a href={url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View on TikTok
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Video className="w-6 h-6 text-pink-600" />
            </div>
            <h3 className="font-medium mb-1">No Watermark</h3>
            <p className="text-sm text-gray-600">Download videos without the TikTok watermark</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Download className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-medium mb-1">HD Quality</h3>
            <p className="text-sm text-gray-600">Get videos in the highest available quality</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Info className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-medium mb-1">Free & Unlimited</h3>
            <p className="text-sm text-gray-600">No registration required, download as many as you want</p>
          </CardContent>
        </Card>
      </div>

      {/* How to Use */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-medium mb-4">How to Download TikTok Videos</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">1</span>
              </div>
              <p className="text-sm text-gray-600">Open TikTok and find the video</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">2</span>
              </div>
              <p className="text-sm text-gray-600">Tap "Share" and copy the link</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">3</span>
              </div>
              <p className="text-sm text-gray-600">Paste the link above</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">4</span>
              </div>
              <p className="text-sm text-gray-600">Download your video</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          This tool is for personal use only. Please respect copyright and TikTok's 
          Terms of Service. Do not redistribute downloaded content without permission.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default TiktokVideoDownloader;
