import { useState } from 'react';
import { Download, Link, AlertCircle, Instagram, ExternalLink, Image as ImageIcon, Copy, Check, Grid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { isValidInstagramUrl, copyToClipboard } from '@/lib/utils';

interface MediaItem {
  id: string;
  url: string;
  type: 'image' | 'video';
  thumbnail?: string;
}

interface PostInfo {
  id: string;
  caption: string;
  author: string;
  media: MediaItem[];
  likes: string;
  timestamp: string;
}

export function InstagramPhotoDownloader() {
  const [url, setUrl] = useState('');
  const [postInfo, setPostInfo] = useState<PostInfo | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setPostInfo(null);
    
    if (!url.trim()) {
      setError('Please enter an Instagram URL');
      return;
    }

    if (!isValidInstagramUrl(url)) {
      setError('Please enter a valid Instagram URL');
      return;
    }

    setLoading(true);
    
    // Simulate API call - in production, this would call a backend service
    // Since Instagram's API requires authentication, this is a demo implementation
    setTimeout(() => {
      const postId = url.split('/p/').pop()?.split('/')[0] || 'demo';
      
      setPostInfo({
        id: postId,
        caption: 'Instagram Post',
        author: '@username',
        likes: '1.2K',
        timestamp: '2 hours ago',
        media: [
          {
            id: '1',
            url: `https://placehold.co/600x600/E4405F/FFFFFF/png?text=Instagram+Photo+1`,
            type: 'image'
          },
          {
            id: '2',
            url: `https://placehold.co/600x600/833AB4/FFFFFF/png?text=Instagram+Photo+2`,
            type: 'image'
          }
        ]
      });
      setLoading(false);
    }, 1500);
  };

  const handleCopy = async () => {
    if (await copyToClipboard(url)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadMedia = (mediaUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = mediaUrl;
    link.download = `instagram-${postInfo?.id}-media-${index + 1}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    postInfo?.media.forEach((media, index) => {
      setTimeout(() => downloadMedia(media.url, index), index * 500);
    });
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Instagram Post URL
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Link className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="https://www.instagram.com/p/..."
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <><Instagram className="w-4 h-4 mr-2" /> Get Photos</>
                  )}
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-500">
              Supports: instagram.com/p/..., instagram.com/reel/..., instagram.com/tv/...
            </p>
          </form>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Post Info */}
      {postInfo && (
        <Card>
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold">{postInfo.author}</h3>
                <p className="text-sm text-gray-500">{postInfo.timestamp} • {postInfo.likes} likes</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleCopy}>
                  {copied ? <><Check className="w-4 h-4 mr-1" /> Copied!</> : <><Copy className="w-4 h-4 mr-1" /> Copy</>}
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-1" />
                    View
                  </a>
                </Button>
              </div>
            </div>

            {/* Caption */}
            <p className="text-gray-700 mb-4">{postInfo.caption}</p>

            {/* Media Grid */}
            <Tabs defaultValue="grid" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="grid"><Grid className="w-4 h-4 mr-1" /> Grid</TabsTrigger>
                <TabsTrigger value="list"><ImageIcon className="w-4 h-4 mr-1" /> List</TabsTrigger>
              </TabsList>

              <TabsContent value="grid">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {postInfo.media.map((media, index) => (
                    <div key={media.id} className="relative group aspect-square">
                      <img
                        src={media.url}
                        alt={`Media ${index + 1}`}
                        className="w-full h-full object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                        <Button 
                          size="sm" 
                          onClick={() => downloadMedia(media.url, index)}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="list">
                <div className="space-y-4">
                  {postInfo.media.map((media, index) => (
                    <div key={media.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <img
                        src={media.url}
                        alt={`Media ${index + 1}`}
                        className="w-20 h-20 object-cover rounded"
                      />
                      <div className="flex-1">
                        <p className="font-medium">Media {index + 1}</p>
                        <p className="text-sm text-gray-500">{media.type === 'image' ? 'Image' : 'Video'}</p>
                      </div>
                      <Button onClick={() => downloadMedia(media.url, index)}>
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            {/* Download All */}
            {postInfo.media.length > 1 && (
              <Button className="w-full mt-4" variant="outline" onClick={downloadAll}>
                <Download className="w-5 h-5 mr-2" />
                Download All ({postInfo.media.length} items)
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <ImageIcon className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium mb-1">High Quality</h3>
            <p className="text-sm text-gray-600">Download photos in original resolution</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <Grid className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium mb-1">Carousel Support</h3>
            <p className="text-sm text-gray-600">Download all photos from multi-posts</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <Download className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium mb-1">Fast & Free</h3>
            <p className="text-sm text-gray-600">No registration, unlimited downloads</p>
          </CardContent>
        </Card>
      </div>

      {/* How to Use */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-medium mb-4">How to Download Instagram Photos</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">1</span>
              </div>
              <p className="text-sm text-gray-600">Open Instagram and find the post</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">2</span>
              </div>
              <p className="text-sm text-gray-600">Tap the three dots and copy link</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">3</span>
              </div>
              <p className="text-sm text-gray-600">Paste the link above</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <span className="font-bold text-gray-600">4</span>
              </div>
              <p className="text-sm text-gray-600">Download your photos</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          This tool is for personal use only. Please respect copyright and Instagram's 
          Terms of Service. Only download content you have permission to use.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default InstagramPhotoDownloader;
