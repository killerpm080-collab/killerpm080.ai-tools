import { useState, useCallback } from 'react';
import { FileText, Copy, Trash2, Type, AlignLeft, Clock, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { copyToClipboard } from '@/lib/utils';

interface TextStats {
  characters: number;
  charactersNoSpaces: number;
  words: number;
  sentences: number;
  paragraphs: number;
  lines: number;
  readingTime: number;
  speakingTime: number;
}

export function WordCounter() {
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);

  const calculateStats = useCallback((input: string): TextStats => {
    const characters = input.length;
    const charactersNoSpaces = input.replace(/\s/g, '').length;
    const words = input.trim() === '' ? 0 : input.trim().split(/\s+/).length;
    const sentences = input.trim() === '' ? 0 : input.split(/[.!?]+/).filter(s => s.trim().length > 0).length;
    const paragraphs = input.trim() === '' ? 0 : input.split(/\n\s*\n/).filter(p => p.trim().length > 0).length;
    const lines = input === '' ? 0 : input.split('\n').length;
    
    // Average reading speed: 200 words per minute
    const readingTime = Math.ceil(words / 200);
    // Average speaking speed: 130 words per minute
    const speakingTime = Math.ceil(words / 130);

    return {
      characters,
      charactersNoSpaces,
      words,
      sentences,
      paragraphs,
      lines,
      readingTime,
      speakingTime
    };
  }, []);

  const stats = calculateStats(text);

  const handleCopy = async () => {
    if (await copyToClipboard(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClear = () => {
    setText('');
  };

  const handlePaste = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      setText(clipboardText);
    } catch (e) {
      console.error('Failed to read clipboard:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Type className="w-6 h-6 mx-auto mb-2 text-blue-600" />
            <p className="text-2xl font-bold">{stats.words.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Words</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <AlignLeft className="w-6 h-6 mx-auto mb-2 text-green-600" />
            <p className="text-2xl font-bold">{stats.characters.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Characters</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <FileText className="w-6 h-6 mx-auto mb-2 text-purple-600" />
            <p className="text-2xl font-bold">{stats.sentences.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Sentences</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <BookOpen className="w-6 h-6 mx-auto mb-2 text-orange-600" />
            <p className="text-2xl font-bold">{stats.paragraphs.toLocaleString()}</p>
            <p className="text-sm text-gray-500">Paragraphs</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Time Estimates
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Reading Time</span>
                <span className="font-medium">
                  {stats.readingTime < 1 ? '< 1 min' : `${stats.readingTime} min`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Speaking Time</span>
                <span className="font-medium">
                  {stats.speakingTime < 1 ? '< 1 min' : `${stats.speakingTime} min`}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3">Character Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">With Spaces</span>
                <span className="font-medium">{stats.characters.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Without Spaces</span>
                <span className="font-medium">{stats.charactersNoSpaces.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Lines</span>
                <span className="font-medium">{stats.lines.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Text Input */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium">Enter Your Text</h3>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handlePaste}>
                Paste
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleCopy}
                disabled={!text}
              >
                {copied ? 'Copied!' : <><Copy className="w-4 h-4 mr-1" /> Copy</>}
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleClear}
                disabled={!text}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Clear
              </Button>
            </div>
          </div>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type or paste your text here..."
            className="min-h-[300px] resize-none"
          />
          <p className="text-xs text-gray-500 mt-2 text-right">
            {stats.characters} characters | {stats.words} words
          </p>
        </CardContent>
      </Card>

      {/* Social Media Limits */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-medium mb-3">Platform Limits</h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Twitter/X Post (280 chars)</span>
                <span className={stats.characters > 280 ? 'text-red-600' : 'text-green-600'}>
                  {stats.characters}/280
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${
                    stats.characters > 280 ? 'bg-red-500' : 'bg-blue-500'
                  }`}
                  style={{ width: `${Math.min((stats.characters / 280) * 100, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Instagram Caption (2,200 chars)</span>
                <span className={stats.characters > 2200 ? 'text-red-600' : 'text-green-600'}>
                  {stats.characters}/2,200
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${
                    stats.characters > 2200 ? 'bg-red-500' : 'bg-pink-500'
                  }`}
                  style={{ width: `${Math.min((stats.characters / 2200) * 100, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Meta Description (160 chars)</span>
                <span className={stats.characters > 160 ? 'text-red-600' : 'text-green-600'}>
                  {stats.characters}/160
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all ${
                    stats.characters > 160 ? 'bg-red-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min((stats.characters / 160) * 100, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default WordCounter;
