import { useState, useCallback } from 'react';
import { Upload, Download, Trash2, Image as ImageIcon, Check, AlertCircle, Lock, Unlock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
// formatFileSize utility available if needed

interface ResizedImage {
  id: string;
  originalFile: File;
  resizedUrl: string | null;
  originalWidth: number;
  originalHeight: number;
  newWidth: number;
  newHeight: number;
  preview: string;
  status: 'pending' | 'resizing' | 'done' | 'error';
}

const presetSizes = [
  { name: 'Custom', width: 0, height: 0 },
  { name: 'Instagram Post (Square)', width: 1080, height: 1080 },
  { name: 'Instagram Story', width: 1080, height: 1920 },
  { name: 'Facebook Post', width: 1200, height: 630 },
  { name: 'Twitter/X Post', width: 1200, height: 675 },
  { name: 'YouTube Thumbnail', width: 1280, height: 720 },
  { name: 'Website Hero', width: 1920, height: 1080 },
  { name: 'Profile Picture', width: 400, height: 400 },
];

export function ImageResizer() {
  const [images, setImages] = useState<ResizedImage[]>([]);
  const [width, setWidth] = useState(800);
  const [height, setHeight] = useState(600);
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [selectedPreset, setSelectedPreset] = useState('Custom');
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(file => 
      file.type.startsWith('image/')
    );
    handleFiles(files);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  }, []);

  const handleFiles = async (files: File[]) => {
    for (const file of files) {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      
      await new Promise((resolve) => {
        img.onload = resolve;
      });

      const newImage: ResizedImage = {
        id: Math.random().toString(36).substring(7),
        originalFile: file,
        resizedUrl: null,
        originalWidth: img.width,
        originalHeight: img.height,
        newWidth: width,
        newHeight: height,
        preview: img.src,
        status: 'pending'
      };

      setImages(prev => [...prev, newImage]);
      await resizeImage(newImage, width, height);
    }
  };

  const resizeImage = async (image: ResizedImage, newWidth: number, newHeight: number) => {
    setImages(prev => prev.map(img => 
      img.id === image.id ? { ...img, status: 'resizing' } : img
    ));

    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      const img = new Image();
      img.src = image.preview;
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      canvas.width = newWidth;
      canvas.height = newHeight;
      
      // Use better quality scaling
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      
      ctx.drawImage(img, 0, 0, newWidth, newHeight);

      const resizedUrl = canvas.toDataURL('image/jpeg', 0.92);

      setImages(prev => prev.map(img => 
        img.id === image.id ? {
          ...img,
          resizedUrl,
          newWidth,
          newHeight,
          status: 'done'
        } : img
      ));
    } catch (error) {
      console.error('Resize error:', error);
      setImages(prev => prev.map(img => 
        img.id === image.id ? { ...img, status: 'error' } : img
      ));
    }
  };

  const handlePresetChange = (presetName: string) => {
    setSelectedPreset(presetName);
    const preset = presetSizes.find(p => p.name === presetName);
    if (preset && preset.width > 0) {
      setWidth(preset.width);
      setHeight(preset.height);
    }
  };

  const handleWidthChange = (newWidth: number) => {
    setWidth(newWidth);
    if (maintainAspectRatio && images.length > 0) {
      const image = images[0];
      const ratio = image.originalHeight / image.originalWidth;
      setHeight(Math.round(newWidth * ratio));
    }
  };

  const handleHeightChange = (newHeight: number) => {
    setHeight(newHeight);
    if (maintainAspectRatio && images.length > 0) {
      const image = images[0];
      const ratio = image.originalWidth / image.originalHeight;
      setWidth(Math.round(newHeight * ratio));
    }
  };

  const downloadImage = (image: ResizedImage) => {
    if (!image.resizedUrl) return;
    
    const link = document.createElement('a');
    link.href = image.resizedUrl;
    link.download = `resized_${image.newWidth}x${image.newHeight}_${image.originalFile.name}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    images.filter(img => img.status === 'done').forEach(downloadImage);
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const image = prev.find(img => img.id === id);
      if (image) {
        URL.revokeObjectURL(image.preview);
      }
      return prev.filter(img => img.id !== id);
    });
  };

  const clearAll = () => {
    images.forEach(image => {
      URL.revokeObjectURL(image.preview);
    });
    setImages([]);
  };

  const reprocessAll = async () => {
    for (const image of images) {
      await resizeImage(image, width, height);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400 bg-gray-50'
          }
        `}
      >
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <Upload className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <p className="text-lg font-medium text-gray-900">
              Drag and drop images here
            </p>
            <p className="text-sm text-gray-500 mt-1">
              or click to browse files
            </p>
          </div>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileInput}
            className="hidden"
            id="resize-input"
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('resize-input')?.click()}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Select Images
          </Button>
          <p className="text-xs text-gray-400">
            Supports JPG, PNG, WebP (Max 10MB each)
          </p>
        </div>
      </div>

      {/* Resize Settings */}
      <Card>
        <CardContent className="p-4 space-y-4">
          <h3 className="font-medium">Resize Settings</h3>
          
          <div>
            <Label>Preset Size</Label>
            <Select value={selectedPreset} onValueChange={handlePresetChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {presetSizes.map(preset => (
                  <SelectItem key={preset.name} value={preset.name}>
                    {preset.name} {preset.width > 0 && `(${preset.width}x${preset.height})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Width (px)</Label>
              <Input
                type="number"
                value={width}
                onChange={(e) => handleWidthChange(parseInt(e.target.value) || 0)}
                min={1}
                max={5000}
              />
            </div>
            <div>
              <Label>Height (px)</Label>
              <Input
                type="number"
                value={height}
                onChange={(e) => handleHeightChange(parseInt(e.target.value) || 0)}
                min={1}
                max={5000}
              />
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setMaintainAspectRatio(!maintainAspectRatio)}
            className="w-full"
          >
            {maintainAspectRatio ? (
              <><Lock className="w-4 h-4 mr-2" /> Aspect Ratio Locked</>
            ) : (
              <><Unlock className="w-4 h-4 mr-2" /> Aspect Ratio Unlocked</>
            )}
          </Button>

          {images.length > 0 && (
            <Button onClick={reprocessAll} className="w-full">
              Apply to All Images
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Image List */}
      {images.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Resized Images</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={downloadAll}>
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
              <Button variant="outline" size="sm" onClick={clearAll} className="text-red-600 hover:bg-red-50">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {images.map((image) => (
              <Card key={image.id} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative">
                  <img
                    src={image.resizedUrl || image.preview}
                    alt={image.originalFile.name}
                    className="w-full h-full object-contain"
                  />
                  {image.status === 'resizing' && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                  {image.status === 'done' && (
                    <div className="absolute top-2 right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <p className="text-sm font-medium truncate" title={image.originalFile.name}>
                    {image.originalFile.name}
                  </p>
                  <div className="mt-2 text-xs text-gray-500 space-y-1">
                    <p>Original: {image.originalWidth}x{image.originalHeight}</p>
                    <p className="text-green-600">New: {image.newWidth}x{image.newHeight}</p>
                  </div>
                  {image.status === 'done' && (
                    <div className="mt-3 flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => downloadImage(image)}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => removeImage(image.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Info Alert */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          Image resizing happens entirely in your browser. Your images are never uploaded to any server.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default ImageResizer;
