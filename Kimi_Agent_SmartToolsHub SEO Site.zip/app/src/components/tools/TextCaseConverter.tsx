import { useState, useCallback } from 'react';
import { Type, Copy, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { copyToClipboard } from '@/lib/utils';

type CaseType = 
  | 'sentence' 
  | 'lower' 
  | 'upper' 
  | 'title' 
  | 'camel' 
  | 'pascal' 
  | 'snake' 
  | 'kebab' 
  | 'alternating'
  | 'inverse';

interface CaseOption {
  id: CaseType;
  name: string;
  description: string;
  example: string;
}

const caseOptions: CaseOption[] = [
  { id: 'sentence', name: 'Sentence case', description: 'First letter capitalized', example: 'This is a sentence.' },
  { id: 'lower', name: 'lowercase', description: 'All letters lowercase', example: 'this is lowercase' },
  { id: 'upper', name: 'UPPERCASE', description: 'All letters uppercase', example: 'THIS IS UPPERCASE' },
  { id: 'title', name: 'Title Case', description: 'First Letter Of Each Word', example: 'This Is Title Case' },
  { id: 'camel', name: 'camelCase', description: 'firstLetterLowerRestUpper', example: 'thisIsCamelCase' },
  { id: 'pascal', name: 'PascalCase', description: 'FirstLetterOfEachWordUpper', example: 'ThisIsPascalCase' },
  { id: 'snake', name: 'snake_case', description: 'words_separated_by_underscores', example: 'this_is_snake_case' },
  { id: 'kebab', name: 'kebab-case', description: 'words-separated-by-hyphens', example: 'this-is-kebab-case' },
  { id: 'alternating', name: 'aLtErNaTiNg', description: 'AlTeRnAtInG cAsE', example: 'ThIs Is AlTeRnAtInG' },
  { id: 'inverse', name: 'iNVERSE', description: 'InVeRsE eAcH lEtTeR', example: 'tHIS IS INVERSE' },
];

export function TextCaseConverter() {
  const [text, setText] = useState('');
  const [convertedText, setConvertedText] = useState('');
  const [copied, setCopied] = useState(false);
  const [lastCase, setLastCase] = useState<CaseType | null>(null);

  const convertCase = useCallback((input: string, caseType: CaseType): string => {
    switch (caseType) {
      case 'sentence':
        return input.toLowerCase().replace(/(^")|(\.\s+)([a-z])/g, (match) => match.toUpperCase());
      
      case 'lower':
        return input.toLowerCase();
      
      case 'upper':
        return input.toUpperCase();
      
      case 'title':
        return input.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
      
      case 'camel':
        return input.toLowerCase()
          .replace(/[^a-zA-Z0-9]+(.)/g, (_, char) => char.toUpperCase())
          .replace(/^[A-Z]/, (char) => char.toLowerCase());
      
      case 'pascal':
        return input.toLowerCase()
          .replace(/[^a-zA-Z0-9]+(.)/g, (_, char) => char.toUpperCase())
          .replace(/^[a-z]/, (char) => char.toUpperCase());
      
      case 'snake':
        return input
          .replace(/\W+/g, ' ')
          .split(/ |\B(?=[A-Z])/)
          .map(word => word.toLowerCase())
          .join('_')
          .replace(/^_+|_+$/g, '');
      
      case 'kebab':
        return input
          .replace(/\W+/g, ' ')
          .split(/ |\B(?=[A-Z])/)
          .map(word => word.toLowerCase())
          .join('-')
          .replace(/^-+|-+$/g, '');
      
      case 'alternating':
        return input.split('').map((char, i) => 
          i % 2 === 0 ? char.toLowerCase() : char.toUpperCase()
        ).join('');
      
      case 'inverse':
        return input.split('').map(char => 
          char === char.toUpperCase() ? char.toLowerCase() : char.toUpperCase()
        ).join('');
      
      default:
        return input;
    }
  }, []);

  const handleConvert = (caseType: CaseType) => {
    const result = convertCase(text, caseType);
    setConvertedText(result);
    setLastCase(caseType);
  };

  const handleCopy = async () => {
    if (await copyToClipboard(convertedText)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClear = () => {
    setText('');
    setConvertedText('');
    setLastCase(null);
  };

  const handlePaste = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      setText(clipboardText);
    } catch (e) {
      console.error('Failed to read clipboard:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium flex items-center gap-2">
              <Type className="w-4 h-4" />
              Input Text
            </h3>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handlePaste}>
                Paste
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleClear}
                disabled={!text}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Clear
              </Button>
            </div>
          </div>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Enter or paste your text here..."
            className="min-h-[150px] resize-none"
          />
          <p className="text-xs text-gray-500 mt-2 text-right">
            {text.length} characters | {text.trim() ? text.trim().split(/\s+/).length : 0} words
          </p>
        </CardContent>
      </Card>

      {/* Case Options */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {caseOptions.map((option) => (
          <Button
            key={option.id}
            variant={lastCase === option.id ? 'default' : 'outline'}
            className="h-auto py-3 flex flex-col items-start text-left"
            onClick={() => handleConvert(option.id)}
            disabled={!text}
          >
            <span className="font-medium text-sm">{option.name}</span>
            <span className="text-xs opacity-70 mt-1">{option.example}</span>
          </Button>
        ))}
      </div>

      {/* Output Section */}
      {convertedText && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium">Converted Text</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={handleCopy}>
                  {copied ? <><Check className="w-4 h-4 mr-1" /> Copied!</> : <><Copy className="w-4 h-4 mr-1" /> Copy</>}
                </Button>
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 min-h-[100px]">
              <p className="break-words whitespace-pre-wrap">{convertedText}</p>
            </div>
            <p className="text-xs text-gray-500 mt-2 text-right">
              {convertedText.length} characters
            </p>
          </CardContent>
        </Card>
      )}

      {/* Quick Tips */}
      <Card>
        <CardContent className="p-4">
          <h3 className="font-medium mb-3">Quick Reference</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium text-gray-700 mb-2">Programming Cases</p>
              <ul className="space-y-1 text-gray-600">
                <li><strong>camelCase</strong> - JavaScript variables</li>
                <li><strong>PascalCase</strong> - Class names</li>
                <li><strong>snake_case</strong> - Python variables</li>
                <li><strong>kebab-case</strong> - CSS classes</li>
              </ul>
            </div>
            <div>
              <p className="font-medium text-gray-700 mb-2">Writing Cases</p>
              <ul className="space-y-1 text-gray-600">
                <li><strong>Sentence case</strong> - Normal writing</li>
                <li><strong>Title Case</strong> - Headlines & titles</li>
                <li><strong>UPPERCASE</strong> - Emphasis</li>
                <li><strong>lowercase</strong> - Casual text</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default TextCaseConverter;
