import { useState, useCallback, useEffect } from 'react';
import { Copy, RefreshCw, Check, Shield, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { copyToClipboard } from '@/lib/utils';

interface PasswordOptions {
  length: number;
  uppercase: boolean;
  lowercase: boolean;
  numbers: boolean;
  symbols: boolean;
  excludeSimilar: boolean;
  excludeAmbiguous: boolean;
}

const CHAR_SETS = {
  uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  lowercase: 'abcdefghijklmnopqrstuvwxyz',
  numbers: '0123456789',
  symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?',
  similar: '0O1lI',
  ambiguous: '{}[]()/\'"`~,;:.<>',
};

export function PasswordGenerator() {
  const [password, setPassword] = useState('');
  const [copied, setCopied] = useState(false);
  const [passwordHistory, setPasswordHistory] = useState<string[]>([]);
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
    excludeSimilar: false,
    excludeAmbiguous: false,
  });

  const generatePassword = useCallback(() => {
    let charset = '';
    if (options.uppercase) charset += CHAR_SETS.uppercase;
    if (options.lowercase) charset += CHAR_SETS.lowercase;
    if (options.numbers) charset += CHAR_SETS.numbers;
    if (options.symbols) charset += CHAR_SETS.symbols;

    if (charset === '') {
      setPassword('');
      return;
    }

    // Exclude similar characters
    if (options.excludeSimilar) {
      for (const char of CHAR_SETS.similar) {
        charset = charset.replace(char, '');
      }
    }

    // Exclude ambiguous characters
    if (options.excludeAmbiguous) {
      for (const char of CHAR_SETS.ambiguous) {
        charset = charset.replace(char, '');
      }
    }

    let newPassword = '';
    const array = new Uint32Array(options.length);
    crypto.getRandomValues(array);

    for (let i = 0; i < options.length; i++) {
      newPassword += charset[array[i] % charset.length];
    }

    setPassword(newPassword);
    setPasswordHistory(prev => [newPassword, ...prev].slice(0, 10));
  }, [options]);

  useEffect(() => {
    generatePassword();
  }, [generatePassword]);

  const handleCopy = async () => {
    if (await copyToClipboard(password)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getPasswordStrength = (pwd: string): { strength: string; color: string; score: number } => {
    let score = 0;
    if (pwd.length >= 8) score++;
    if (pwd.length >= 12) score++;
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^a-zA-Z0-9]/.test(pwd)) score++;

    const strengths = [
      { strength: 'Very Weak', color: 'bg-red-600' },
      { strength: 'Weak', color: 'bg-red-500' },
      { strength: 'Fair', color: 'bg-yellow-500' },
      { strength: 'Good', color: 'bg-blue-500' },
      { strength: 'Strong', color: 'bg-green-500' },
      { strength: 'Very Strong', color: 'bg-green-600' },
    ];

    return { ...strengths[score], score };
  };

  const strength = getPasswordStrength(password);

  return (
    <div className="space-y-6">
      {/* Password Display */}
      <Card className="border-2">
        <CardContent className="p-6">
          <div className="relative">
            <div className="bg-gray-100 rounded-lg p-4 min-h-[80px] flex items-center justify-center">
              <p className="text-2xl md:text-3xl font-mono break-all text-center">
                {password}
              </p>
            </div>
            <div className="absolute top-2 right-2 flex gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCopy}
                className={copied ? 'text-green-600' : ''}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Strength Bar */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Password Strength</span>
              <span className={`text-sm font-medium ${
                strength.score >= 4 ? 'text-green-600' : 
                strength.score >= 3 ? 'text-blue-600' : 
                strength.score >= 2 ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {strength.strength}
              </span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-300 ${strength.color}`}
                style={{ width: `${((strength.score + 1) / 6) * 100}%` }}
              />
            </div>
          </div>

          {/* Generate Button */}
          <Button 
            onClick={generatePassword} 
            className="w-full mt-4"
            size="lg"
          >
            <RefreshCw className="w-5 h-5 mr-2" />
            Generate New Password
          </Button>
        </CardContent>
      </Card>

      {/* Options */}
      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Settings2 className="w-5 h-5 text-gray-500" />
            <h3 className="font-medium">Password Options</h3>
          </div>

          {/* Length Slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium">Password Length</label>
              <span className="text-sm text-gray-500">{options.length} characters</span>
            </div>
            <Slider
              value={[options.length]}
              onValueChange={(value) => setOptions(prev => ({ ...prev, length: value[0] }))}
              min={4}
              max={64}
              step={1}
            />
          </div>

          {/* Character Options */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="uppercase"
                  checked={options.uppercase}
                  onCheckedChange={(checked) => 
                    setOptions(prev => ({ ...prev, uppercase: checked as boolean }))
                  }
                />
                <label htmlFor="uppercase" className="text-sm">
                  Uppercase Letters (A-Z)
                </label>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="lowercase"
                  checked={options.lowercase}
                  onCheckedChange={(checked) => 
                    setOptions(prev => ({ ...prev, lowercase: checked as boolean }))
                  }
                />
                <label htmlFor="lowercase" className="text-sm">
                  Lowercase Letters (a-z)
                </label>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="numbers"
                  checked={options.numbers}
                  onCheckedChange={(checked) => 
                    setOptions(prev => ({ ...prev, numbers: checked as boolean }))
                  }
                />
                <label htmlFor="numbers" className="text-sm">
                  Numbers (0-9)
                </label>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="symbols"
                  checked={options.symbols}
                  onCheckedChange={(checked) => 
                    setOptions(prev => ({ ...prev, symbols: checked as boolean }))
                  }
                />
                <label htmlFor="symbols" className="text-sm">
                  Special Symbols (!@#$%^&*)
                </label>
              </div>
            </div>

            <div className="border-t pt-3 mt-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="exclude-similar"
                  checked={options.excludeSimilar}
                  onCheckedChange={(checked) => 
                    setOptions(prev => ({ ...prev, excludeSimilar: checked as boolean }))
                  }
                />
                <label htmlFor="exclude-similar" className="text-sm">
                  Exclude Similar Characters (0, O, 1, l, I)
                </label>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="exclude-ambiguous"
                checked={options.excludeAmbiguous}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, excludeAmbiguous: checked as boolean }))
                }
              />
              <label htmlFor="exclude-ambiguous" className="text-sm">
                Exclude Ambiguous Characters {'{}[]()/\'"`~,;:.<>?'}
              </label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Password History */}
      {passwordHistory.length > 1 && (
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3">Recent Passwords</h3>
            <div className="space-y-2">
              {passwordHistory.slice(1, 6).map((pwd, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded-lg"
                >
                  <code className="text-sm truncate max-w-[200px] md:max-w-[300px]">
                    {pwd}
                  </code>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(pwd)}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Security Tips */}
      <Alert>
        <Shield className="w-4 h-4" />
        <AlertDescription>
          <strong>Security Tips:</strong> Use passwords with at least 12 characters, 
          including uppercase, lowercase, numbers, and symbols. Never reuse passwords 
          across different accounts.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default PasswordGenerator;
