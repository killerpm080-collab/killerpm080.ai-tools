import { useState } from 'react';
import { Download, Link, AlertCircle, Youtube, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { extractYouTubeId, isValidYouTubeUrl } from '@/lib/utils';

interface ThumbnailQuality {
  quality: string;
  url: string;
  resolution: string;
}

export function YoutubeThumbnailDownloader() {
  const [url, setUrl] = useState('');
  const [videoId, setVideoId] = useState<string | null>(null);
  const [thumbnails, setThumbnails] = useState<ThumbnailQuality[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setThumbnails([]);
    
    if (!url.trim()) {
      setError('Please enter a YouTube URL');
      return;
    }

    if (!isValidYouTubeUrl(url)) {
      setError('Please enter a valid YouTube URL');
      return;
    }

    setLoading(true);
    
    const id = extractYouTubeId(url);
    if (!id) {
      setError('Could not extract video ID from URL');
      setLoading(false);
      return;
    }

    setVideoId(id);

    // Generate thumbnail URLs for all qualities
    const thumbnailQualities: ThumbnailQuality[] = [
      {
        quality: 'Max Resolution',
        url: `https://img.youtube.com/vi/${id}/maxresdefault.jpg`,
        resolution: '1280x720'
      },
      {
        quality: 'Standard Definition',
        url: `https://img.youtube.com/vi/${id}/sddefault.jpg`,
        resolution: '640x480'
      },
      {
        quality: 'High Quality',
        url: `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
        resolution: '480x360'
      },
      {
        quality: 'Medium Quality',
        url: `https://img.youtube.com/vi/${id}/mqdefault.jpg`,
        resolution: '320x180'
      },
      {
        quality: 'Default',
        url: `https://img.youtube.com/vi/${id}/default.jpg`,
        resolution: '120x90'
      }
    ];

    setThumbnails(thumbnailQualities);
    setLoading(false);
  };

  const downloadThumbnail = async (thumbnailUrl: string, quality: string) => {
    try {
      const response = await fetch(thumbnailUrl);
      if (!response.ok) throw new Error('Failed to fetch image');
      
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `youtube-thumbnail-${videoId}-${quality.toLowerCase().replace(/\s+/g, '-')}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(blobUrl);
    } catch (e) {
      console.error('Download failed:', e);
      // Fallback: open in new tab
      window.open(thumbnailUrl, '_blank');
    }
  };

  const openThumbnail = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                YouTube Video URL
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Link className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button type="submit" disabled={loading}>
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <><Youtube className="w-4 h-4 mr-2" /> Get Thumbnails</>
                  )}
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-500">
              Supports: youtube.com/watch?v=..., youtu.be/..., youtube.com/shorts/...
            </p>
          </form>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Thumbnails Grid */}
      {thumbnails.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Available Thumbnails</h3>
            <a 
              href={`https://www.youtube.com/watch?v=${videoId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-blue-600 hover:underline flex items-center gap-1"
            >
              View Video <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {thumbnails.map((thumb) => (
              <Card key={thumb.quality} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative group">
                  <img
                    src={thumb.url}
                    alt={`${thumb.quality} thumbnail`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100%25" height="100%25"%3E%3Crect width="100%25" height="100%25" fill="%23f3f4f6"/%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" fill="%239ca3af"%3ENot Available%3C/text%3E%3C/svg%3E';
                    }}
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button 
                      size="sm" 
                      variant="secondary"
                      onClick={() => openThumbnail(thumb.url)}
                    >
                      <ImageIcon className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{thumb.quality}</h4>
                    <span className="text-xs text-gray-500">{thumb.resolution}</span>
                  </div>
                  <Button 
                    size="sm" 
                    className="w-full"
                    onClick={() => downloadThumbnail(thumb.url, thumb.quality)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Info Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3 flex items-center gap-2">
              <Youtube className="w-5 h-5 text-red-600" />
              How It Works
            </h3>
            <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
              <li>Copy the YouTube video URL</li>
              <li>Paste it in the input field above</li>
              <li>Click "Get Thumbnails"</li>
              <li>Download your preferred quality</li>
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3">Available Qualities</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li><strong>Max Resolution</strong> - 1280x720 (HD)</li>
              <li><strong>Standard</strong> - 640x480 (SD)</li>
              <li><strong>High Quality</strong> - 480x360 (HQ)</li>
              <li><strong>Medium Quality</strong> - 320x180 (MQ)</li>
              <li><strong>Default</strong> - 120x90</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Disclaimer */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          This tool is for educational purposes only. Please respect copyright and 
          YouTube's Terms of Service when using downloaded thumbnails.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default YoutubeThumbnailDownloader;
