import { useState, useCallback } from 'react';
import { Upload, Download, Trash2, Image as ImageIcon, Check, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { formatFileSize } from '@/lib/utils';
import imageCompression from 'browser-image-compression';

interface CompressedImage {
  id: string;
  originalFile: File;
  compressedFile: File | null;
  originalSize: number;
  compressedSize: number;
  preview: string;
  status: 'pending' | 'compressing' | 'done' | 'error';
}

export function ImageCompressor() {
  const [images, setImages] = useState<CompressedImage[]>([]);
  const [quality, setQuality] = useState(80);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(file => 
      file.type.startsWith('image/')
    );
    handleFiles(files);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  }, []);

  const handleFiles = async (files: File[]) => {
    const newImages: CompressedImage[] = files.map(file => ({
      id: Math.random().toString(36).substring(7),
      originalFile: file,
      compressedFile: null,
      originalSize: file.size,
      compressedSize: 0,
      preview: URL.createObjectURL(file),
      status: 'pending'
    }));

    setImages(prev => [...prev, ...newImages]);

    // Compress each image
    for (const image of newImages) {
      await compressImage(image);
    }
  };

  const compressImage = async (image: CompressedImage) => {
    setImages(prev => prev.map(img => 
      img.id === image.id ? { ...img, status: 'compressing' } : img
    ));

    try {
      const options = {
        maxSizeMB: image.originalFile.size / (1024 * 1024) * (quality / 100),
        maxWidthOrHeight: 1920,
        useWebWorker: true,
        fileType: image.originalFile.type
      };

      const compressedFile = await imageCompression(image.originalFile, options);
      
      setImages(prev => prev.map(img => 
        img.id === image.id ? {
          ...img,
          compressedFile,
          compressedSize: compressedFile.size,
          status: 'done'
        } : img
      ));
    } catch (error) {
      console.error('Compression error:', error);
      setImages(prev => prev.map(img => 
        img.id === image.id ? { ...img, status: 'error' } : img
      ));
    }
  };

  const downloadImage = (image: CompressedImage) => {
    if (!image.compressedFile) return;
    
    const url = URL.createObjectURL(image.compressedFile);
    const link = document.createElement('a');
    link.href = url;
    link.download = `compressed_${image.originalFile.name}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadAll = () => {
    images.filter(img => img.status === 'done').forEach(downloadImage);
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const image = prev.find(img => img.id === id);
      if (image) {
        URL.revokeObjectURL(image.preview);
      }
      return prev.filter(img => img.id !== id);
    });
  };

  const clearAll = () => {
    images.forEach(image => {
      URL.revokeObjectURL(image.preview);
    });
    setImages([]);
  };

  const totalOriginalSize = images.reduce((sum, img) => sum + img.originalSize, 0);
  const totalCompressedSize = images.reduce((sum, img) => sum + img.compressedSize, 0);
  const totalSavings = totalOriginalSize - totalCompressedSize;
  const savingsPercent = totalOriginalSize > 0 ? Math.round((totalSavings / totalOriginalSize) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400 bg-gray-50'
          }
        `}
      >
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <Upload className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <p className="text-lg font-medium text-gray-900">
              Drag and drop images here
            </p>
            <p className="text-sm text-gray-500 mt-1">
              or click to browse files
            </p>
          </div>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileInput}
            className="hidden"
            id="image-input"
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('image-input')?.click()}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Select Images
          </Button>
          <p className="text-xs text-gray-400">
            Supports JPG, PNG, WebP (Max 10MB each)
          </p>
        </div>
      </div>

      {/* Quality Slider */}
      {images.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium">Compression Quality</label>
              <span className="text-sm text-gray-500">{quality}%</span>
            </div>
            <Slider
              value={[quality]}
              onValueChange={(value) => setQuality(value[0])}
              min={1}
              max={100}
              step={1}
            />
            <p className="text-xs text-gray-500 mt-2">
              Higher quality = larger file size
            </p>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      {images.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-blue-600">{images.length}</p>
              <p className="text-sm text-gray-500">Images</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-gray-700">{formatFileSize(totalOriginalSize)}</p>
              <p className="text-sm text-gray-500">Original Size</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-green-600">{formatFileSize(totalCompressedSize)}</p>
              <p className="text-sm text-gray-500">Compressed Size</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-purple-600">{savingsPercent}%</p>
              <p className="text-sm text-gray-500">Saved</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Image List */}
      {images.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Compressed Images</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={downloadAll}>
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
              <Button variant="outline" size="sm" onClick={clearAll} className="text-red-600 hover:bg-red-50">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {images.map((image) => (
              <Card key={image.id} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative">
                  <img
                    src={image.preview}
                    alt={image.originalFile.name}
                    className="w-full h-full object-contain"
                  />
                  {image.status === 'compressing' && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                  {image.status === 'done' && (
                    <div className="absolute top-2 right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <p className="text-sm font-medium truncate" title={image.originalFile.name}>
                    {image.originalFile.name}
                  </p>
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <span>{formatFileSize(image.originalSize)}</span>
                    <span className="text-green-600">
                      {formatFileSize(image.compressedSize)}
                    </span>
                  </div>
                  {image.status === 'done' && (
                    <div className="mt-3 flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => downloadImage(image)}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => removeImage(image.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Info Alert */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          All image processing happens in your browser. Your images are never uploaded to any server.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default ImageCompressor;
