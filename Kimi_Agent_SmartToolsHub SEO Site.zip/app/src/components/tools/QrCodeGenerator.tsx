import { useState, useRef, useCallback } from 'react';
import { Download, Copy, RefreshCw, QrCode, Link, Type, Wifi, Mail, Phone, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import QRCode from 'qrcode';

type QRType = 'url' | 'text' | 'wifi' | 'email' | 'phone';

interface WiFiConfig {
  ssid: string;
  password: string;
  encryption: 'WPA' | 'WEP' | 'nopass';
}

export function QrCodeGenerator() {
  const [activeTab, setActiveTab] = useState<QRType>('url');
  const [qrData, setQrData] = useState('');
  const [qrImage, setQrImage] = useState('');
  const [size, setSize] = useState(256);
  const [errorLevel, setErrorLevel] = useState<'L' | 'M' | 'Q' | 'H'>('M');
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // WiFi specific state
  const [wifiConfig, setWifiConfig] = useState<WiFiConfig>({
    ssid: '',
    password: '',
    encryption: 'WPA'
  });

  // Email specific state
  const [emailData, setEmailData] = useState({
    to: '',
    subject: '',
    body: ''
  });

  // Phone specific state
  const [phoneNumber, setPhoneNumber] = useState('');

  const generateQR = useCallback(async () => {
    let data = '';
    
    switch (activeTab) {
      case 'url':
      case 'text':
        data = qrData;
        break;
      case 'wifi':
        data = `WIFI:S:${wifiConfig.ssid};T:${wifiConfig.encryption};P:${wifiConfig.password};;`;
        break;
      case 'email':
        data = `mailto:${emailData.to}?subject=${encodeURIComponent(emailData.subject)}&body=${encodeURIComponent(emailData.body)}`;
        break;
      case 'phone':
        data = `tel:${phoneNumber}`;
        break;
    }

    if (!data) return;

    try {
      const canvas = canvasRef.current;
      if (!canvas) return;

      await QRCode.toCanvas(canvas, data, {
        width: size,
        margin: 2,
        errorCorrectionLevel: errorLevel,
        color: {
          dark: '#000000',
          light: '#ffffff'
        }
      });

      setQrImage(canvas.toDataURL('image/png'));
    } catch (error) {
      console.error('QR generation error:', error);
    }
  }, [activeTab, qrData, wifiConfig, emailData, phoneNumber, size, errorLevel]);

  const handleDownload = () => {
    if (!qrImage) return;
    
    const link = document.createElement('a');
    link.href = qrImage;
    link.download = `qrcode-${activeTab}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopy = async () => {
    if (!qrImage) return;
    
    try {
      const response = await fetch(qrImage);
      const blob = await response.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Copy failed:', e);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <Card>
          <CardContent className="p-4">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as QRType)}>
              <TabsList className="grid grid-cols-5 mb-4">
                <TabsTrigger value="url"><Link className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="text"><Type className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="wifi"><Wifi className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="email"><Mail className="w-4 h-4" /></TabsTrigger>
                <TabsTrigger value="phone"><Phone className="w-4 h-4" /></TabsTrigger>
              </TabsList>

              <TabsContent value="url" className="space-y-4">
                <div>
                  <Label>Website URL</Label>
                  <Input
                    placeholder="https://example.com"
                    value={qrData}
                    onChange={(e) => setQrData(e.target.value)}
                  />
                </div>
              </TabsContent>

              <TabsContent value="text" className="space-y-4">
                <div>
                  <Label>Text Content</Label>
                  <Textarea
                    placeholder="Enter any text..."
                    value={qrData}
                    onChange={(e) => setQrData(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
              </TabsContent>

              <TabsContent value="wifi" className="space-y-4">
                <div>
                  <Label>Network Name (SSID)</Label>
                  <Input
                    placeholder="WiFi Network Name"
                    value={wifiConfig.ssid}
                    onChange={(e) => setWifiConfig(prev => ({ ...prev, ssid: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Password</Label>
                  <Input
                    type="password"
                    placeholder="WiFi Password"
                    value={wifiConfig.password}
                    onChange={(e) => setWifiConfig(prev => ({ ...prev, password: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Encryption</Label>
                  <Select 
                    value={wifiConfig.encryption} 
                    onValueChange={(v) => setWifiConfig(prev => ({ ...prev, encryption: v as WiFiConfig['encryption'] }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="WPA">WPA/WPA2</SelectItem>
                      <SelectItem value="WEP">WEP</SelectItem>
                      <SelectItem value="nopass">No Password</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              <TabsContent value="email" className="space-y-4">
                <div>
                  <Label>To</Label>
                  <Input
                    type="email"
                    placeholder="recipient@example.com"
                    value={emailData.to}
                    onChange={(e) => setEmailData(prev => ({ ...prev, to: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Subject</Label>
                  <Input
                    placeholder="Email Subject"
                    value={emailData.subject}
                    onChange={(e) => setEmailData(prev => ({ ...prev, subject: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Body</Label>
                  <Textarea
                    placeholder="Email body text..."
                    value={emailData.body}
                    onChange={(e) => setEmailData(prev => ({ ...prev, body: e.target.value }))}
                    className="min-h-[80px]"
                  />
                </div>
              </TabsContent>

              <TabsContent value="phone" className="space-y-4">
                <div>
                  <Label>Phone Number</Label>
                  <Input
                    type="tel"
                    placeholder="+1234567890"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>
              </TabsContent>
            </Tabs>

            {/* QR Settings */}
            <div className="mt-6 space-y-4 border-t pt-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label>QR Code Size</Label>
                  <span className="text-sm text-gray-500">{size}px</span>
                </div>
                <Slider
                  value={[size]}
                  onValueChange={(value) => setSize(value[0])}
                  min={128}
                  max={1024}
                  step={64}
                />
              </div>

              <div>
                <Label>Error Correction Level</Label>
                <Select value={errorLevel} onValueChange={(v) => setErrorLevel(v as typeof errorLevel)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="L">Low (7%)</SelectItem>
                    <SelectItem value="M">Medium (15%)</SelectItem>
                    <SelectItem value="Q">Quartile (25%)</SelectItem>
                    <SelectItem value="H">High (30%)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={generateQR} className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Generate QR Code
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Preview Section */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-4 flex items-center gap-2">
              <QrCode className="w-5 h-5" />
              QR Code Preview
            </h3>
            
            <div className="flex flex-col items-center">
              <canvas ref={canvasRef} className="hidden" />
              
              {qrImage ? (
                <div className="bg-white p-4 rounded-lg shadow-inner">
                  <img 
                    src={qrImage} 
                    alt="Generated QR Code" 
                    className="max-w-full"
                    style={{ width: Math.min(size, 300) }}
                  />
                </div>
              ) : (
                <div className="w-64 h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-400">
                    <QrCode className="w-16 h-16 mx-auto mb-2" />
                    <p>QR code will appear here</p>
                  </div>
                </div>
              )}

              {qrImage && (
                <div className="flex gap-2 mt-4">
                  <Button onClick={handleDownload} variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download PNG
                  </Button>
                  <Button onClick={handleCopy} variant="outline">
                    {copied ? <><Check className="w-4 h-4 mr-2" /> Copied!</> : <><Copy className="w-4 h-4 mr-2" /> Copy</>}
                  </Button>
                </div>
              )}
            </div>

            {/* Usage Tips */}
            <div className="mt-6 bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Tips</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Test your QR code before printing</li>
                <li>• Higher error correction = more reliable scanning</li>
                <li>• Minimum recommended size: 2cm x 2cm when printed</li>
                <li>• Ensure good contrast for best results</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default QrCodeGenerator;
