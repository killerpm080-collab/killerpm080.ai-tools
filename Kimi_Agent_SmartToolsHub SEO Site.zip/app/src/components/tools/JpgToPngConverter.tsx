import { useState, useCallback } from 'react';
import { Upload, Download, Trash2, Image as ImageIcon, Check, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { formatFileSize } from '@/lib/utils';

interface ConvertedImage {
  id: string;
  originalFile: File;
  convertedUrl: string | null;
  originalSize: number;
  convertedSize: number;
  preview: string;
  status: 'pending' | 'converting' | 'done' | 'error';
}

export function JpgToPngConverter() {
  const [images, setImages] = useState<ConvertedImage[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files).filter(file => 
      file.type === 'image/jpeg' || file.type === 'image/jpg'
    );
    handleFiles(files);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).filter(file => 
      file.type === 'image/jpeg' || file.type === 'image/jpg'
    );
    handleFiles(files);
  }, []);

  const handleFiles = async (files: File[]) => {
    const newImages: ConvertedImage[] = files.map(file => ({
      id: Math.random().toString(36).substring(7),
      originalFile: file,
      convertedUrl: null,
      originalSize: file.size,
      convertedSize: 0,
      preview: URL.createObjectURL(file),
      status: 'pending'
    }));

    setImages(prev => [...prev, ...newImages]);

    // Convert each image
    for (const image of newImages) {
      await convertImage(image);
    }
  };

  const convertImage = async (image: ConvertedImage) => {
    setImages(prev => prev.map(img => 
      img.id === image.id ? { ...img, status: 'converting' } : img
    ));

    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      const img = new Image();
      img.src = image.preview;
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      const convertedUrl = canvas.toDataURL('image/png');
      
      // Calculate converted size
      const base64String = convertedUrl.split(',')[1];
      const convertedSize = Math.ceil((base64String.length * 3) / 4);

      setImages(prev => prev.map(img => 
        img.id === image.id ? {
          ...img,
          convertedUrl,
          convertedSize,
          status: 'done'
        } : img
      ));
    } catch (error) {
      console.error('Conversion error:', error);
      setImages(prev => prev.map(img => 
        img.id === image.id ? { ...img, status: 'error' } : img
      ));
    }
  };

  const downloadImage = (image: ConvertedImage) => {
    if (!image.convertedUrl) return;
    
    const link = document.createElement('a');
    link.href = image.convertedUrl;
    link.download = image.originalFile.name.replace(/\.(jpg|jpeg)$/i, '.png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    images.filter(img => img.status === 'done').forEach(downloadImage);
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const image = prev.find(img => img.id === id);
      if (image) {
        URL.revokeObjectURL(image.preview);
      }
      return prev.filter(img => img.id !== id);
    });
  };

  const clearAll = () => {
    images.forEach(image => {
      URL.revokeObjectURL(image.preview);
    });
    setImages([]);
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400 bg-gray-50'
          }
        `}
      >
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <Upload className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <p className="text-lg font-medium text-gray-900">
              Drag and drop JPG images here
            </p>
            <p className="text-sm text-gray-500 mt-1">
              or click to browse files
            </p>
          </div>
          <input
            type="file"
            accept="image/jpeg,image/jpg"
            multiple
            onChange={handleFileInput}
            className="hidden"
            id="jpg-input"
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('jpg-input')?.click()}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Select JPG Files
          </Button>
          <p className="text-xs text-gray-400">
            JPG/JPEG files only (Max 10MB each)
          </p>
        </div>
      </div>

      {/* Image List */}
      {images.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Converted Images</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={downloadAll}>
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
              <Button variant="outline" size="sm" onClick={clearAll} className="text-red-600 hover:bg-red-50">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {images.map((image) => (
              <Card key={image.id} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative">
                  <img
                    src={image.preview}
                    alt={image.originalFile.name}
                    className="w-full h-full object-contain"
                  />
                  {image.status === 'converting' && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                  {image.status === 'done' && (
                    <div className="absolute top-2 right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <p className="text-sm font-medium truncate" title={image.originalFile.name}>
                    {image.originalFile.name}
                  </p>
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <span>JPG: {formatFileSize(image.originalSize)}</span>
                    <span className="text-green-600">
                      PNG: {formatFileSize(image.convertedSize)}
                    </span>
                  </div>
                  {image.status === 'done' && (
                    <div className="mt-3 flex gap-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => downloadImage(image)}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download PNG
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => removeImage(image.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Info Alert */}
      <Alert>
        <AlertCircle className="w-4 h-4" />
        <AlertDescription>
          JPG to PNG conversion happens entirely in your browser. Your images are never uploaded to any server.
          Note: PNG files may be larger than the original JPG files since PNG is a lossless format.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default JpgToPngConverter;
