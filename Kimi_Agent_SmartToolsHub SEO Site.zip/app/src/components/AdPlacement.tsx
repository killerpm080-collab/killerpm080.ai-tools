import { cn } from '@/lib/utils';

interface AdPlacementProps {
  location: 'header' | 'sidebar' | 'in-content' | 'footer';
  className?: string;
}

// This is a placeholder component for ad placements
// In production, you would integrate with Google AdSense, Ad Manager, or other ad networks

export function AdPlacement({ location, className }: AdPlacementProps) {
  const adConfigs = {
    header: {
      width: '728px',
      height: '90px',
      label: 'Header Ad',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    sidebar: {
      width: '300px',
      height: '250px',
      label: 'Sidebar Ad',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600'
    },
    'in-content': {
      width: '728px',
      height: '90px',
      label: 'In-Content Ad',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    },
    footer: {
      width: '728px',
      height: '90px',
      label: 'Footer Ad',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600'
    }
  };

  const config = adConfigs[location];

  return (
    <div 
      className={cn(
        'flex items-center justify-center rounded-lg border-2 border-dashed border-gray-300 my-4',
        config.bgColor,
        className
      )}
      style={{ 
        maxWidth: '100%',
        width: config.width,
        height: config.height,
        minHeight: '90px'
      }}
    >
      <div className="text-center p-4">
        <span className={cn('text-sm font-medium', config.textColor)}>
          {config.label} - Ad Space
        </span>
        <p className="text-xs text-gray-500 mt-1">
          {config.width} × {config.height}
        </p>
      </div>
    </div>
  );
}

// Responsive ad component that adapts to container width
export function ResponsiveAd({ 
  slot,
  format = 'auto',
  className 
}: { 
  slot: string;
  format?: string;
  className?: string;
}) {
  return (
    <div className={cn('ad-container my-4', className)}>
      {/* Google AdSense code would go here */}
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
      <div className="text-xs text-center text-gray-400 mt-1">Advertisement</div>
    </div>
  );
}

// Sticky sidebar ad
export function StickySidebarAd({ className }: { className?: string }) {
  return (
    <div className={cn('sticky top-24', className)}>
      <AdPlacement location="sidebar" />
    </div>
  );
}

// In-tool ad - displayed within tool interfaces
export function InToolAd({ className }: { className?: string }) {
  return (
    <div className={cn('my-6', className)}>
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-100">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-indigo-900">Sponsored</p>
            <p className="text-xs text-indigo-600 mt-1">
              Upgrade to Premium for ad-free experience
            </p>
          </div>
          <button className="px-4 py-2 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition-colors">
            Learn More
          </button>
        </div>
      </div>
    </div>
  );
}

export default AdPlacement;
