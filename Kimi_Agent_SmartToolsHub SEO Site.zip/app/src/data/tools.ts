import type { Tool, Category, BlogPost } from '@/types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Image Tools',
    slug: 'image-tools',
    description: 'Free online image editing and conversion tools. Compress, resize, and convert images easily.',
    icon: 'Image',
    toolCount: 4
  },
  {
    id: '2',
    name: 'Security Tools',
    slug: 'security-tools',
    description: 'Secure password generators and security utilities to keep your data safe.',
    icon: 'Shield',
    toolCount: 1
  },
  {
    id: '3',
    name: 'Text Tools',
    slug: 'text-tools',
    description: 'Useful text manipulation tools including word counters and case converters.',
    icon: 'Type',
    toolCount: 2
  },
  {
    id: '4',
    name: 'Generator Tools',
    slug: 'generator-tools',
    description: 'QR code generators and other useful creation tools.',
    icon: 'QrCode',
    toolCount: 1
  },
  {
    id: '5',
    name: 'Downloader Tools',
    slug: 'downloader-tools',
    description: 'Download videos and images from popular social media platforms.',
    icon: 'Download',
    toolCount: 3
  }
];

export const tools: Tool[] = [
  {
    id: '1',
    name: 'Image Compressor',
    description: 'Compress images online without losing quality. Reduce file size for JPG, PNG, and WebP images.',
    slug: 'image-compressor',
    category: 'image-tools',
    icon: 'Image',
    featured: true,
    metaTitle: 'Free Image Compressor Online | Reduce Image Size Without Quality Loss',
    metaDescription: 'Compress images online for free. Reduce JPG, PNG, and WebP file sizes without losing quality. Fast, secure, and easy to use image compression tool.',
    keywords: ['image compressor', 'compress images', 'reduce image size', 'jpg compressor', 'png compressor', 'optimize images']
  },
  {
    id: '2',
    name: 'PNG to JPG Converter',
    description: 'Convert PNG images to JPG format online. Free, fast, and secure conversion tool.',
    slug: 'png-to-jpg-converter',
    category: 'image-tools',
    icon: 'Image',
    featured: true,
    metaTitle: 'PNG to JPG Converter Free Online | Convert Images Instantly',
    metaDescription: 'Convert PNG to JPG online for free. Fast, secure, and high-quality image conversion. No registration required.',
    keywords: ['png to jpg', 'convert png to jpg', 'png converter', 'image converter', 'png to jpeg']
  },
  {
    id: '3',
    name: 'JPG to PNG Converter',
    description: 'Convert JPG images to PNG format with transparency support. Free online converter.',
    slug: 'jpg-to-png-converter',
    category: 'image-tools',
    icon: 'Image',
    featured: false,
    metaTitle: 'JPG to PNG Converter Online Free | Convert with Transparency',
    metaDescription: 'Convert JPG to PNG online for free. Create transparent PNG images from JPG files. Fast and secure conversion tool.',
    keywords: ['jpg to png', 'convert jpg to png', 'jpg converter', 'create transparent png', 'image converter']
  },
  {
    id: '4',
    name: 'Image Resizer',
    description: 'Resize images to exact dimensions. Perfect for social media, websites, and printing.',
    slug: 'image-resizer',
    category: 'image-tools',
    icon: 'Maximize',
    featured: true,
    metaTitle: 'Free Image Resizer Online | Resize Photos for Social Media',
    metaDescription: 'Resize images online for free. Adjust dimensions for Instagram, Facebook, Twitter, and more. Fast, easy, and secure image resizing tool.',
    keywords: ['image resizer', 'resize images', 'photo resizer', 'resize photos', 'image dimensions', 'social media images']
  },
  {
    id: '5',
    name: 'Password Generator',
    description: 'Generate strong, secure passwords with customizable length and character options.',
    slug: 'password-generator',
    category: 'security-tools',
    icon: 'Lock',
    featured: true,
    metaTitle: 'Free Password Generator | Create Strong & Secure Passwords',
    metaDescription: 'Generate strong, secure passwords instantly. Customize length, symbols, numbers, and more. Free online password generator tool.',
    keywords: ['password generator', 'strong password', 'secure password', 'random password', 'password creator', 'generate password']
  },
  {
    id: '6',
    name: 'Word Counter',
    description: 'Count words, characters, sentences, and paragraphs in your text instantly.',
    slug: 'word-counter',
    category: 'text-tools',
    icon: 'FileText',
    featured: true,
    metaTitle: 'Word Counter Online | Count Words, Characters & More',
    metaDescription: 'Free online word counter tool. Count words, characters, sentences, and paragraphs instantly. Perfect for essays, articles, and social media posts.',
    keywords: ['word counter', 'character counter', 'word count tool', 'text counter', 'count words online']
  },
  {
    id: '7',
    name: 'Text Case Converter',
    description: 'Convert text between uppercase, lowercase, title case, and more.',
    slug: 'text-case-converter',
    category: 'text-tools',
    icon: 'Type',
    featured: false,
    metaTitle: 'Text Case Converter Online | Uppercase, Lowercase, Title Case',
    metaDescription: 'Convert text case online for free. Change to uppercase, lowercase, title case, sentence case, and more. Easy text transformation tool.',
    keywords: ['text case converter', 'uppercase converter', 'lowercase converter', 'title case', 'change text case']
  },
  {
    id: '8',
    name: 'QR Code Generator',
    description: 'Generate QR codes for URLs, text, contact info, and more. Free and easy to use.',
    slug: 'qr-code-generator',
    category: 'generator-tools',
    icon: 'QrCode',
    featured: true,
    metaTitle: 'Free QR Code Generator Online | Create QR Codes Instantly',
    metaDescription: 'Generate QR codes for free. Create codes for URLs, text, WiFi, contact cards, and more. Customizable and downloadable QR code generator.',
    keywords: ['qr code generator', 'create qr code', 'generate qr code', 'free qr code', 'qr code maker']
  },
  {
    id: '9',
    name: 'YouTube Thumbnail Downloader',
    description: 'Download high-quality thumbnails from YouTube videos in multiple resolutions.',
    slug: 'youtube-thumbnail-downloader',
    category: 'downloader-tools',
    icon: 'Youtube',
    featured: true,
    metaTitle: 'YouTube Thumbnail Downloader | Download HD Thumbnails Free',
    metaDescription: 'Download YouTube thumbnails in HD quality. Get thumbnails in multiple resolutions including 1080p, 720p, and more. Free and easy to use.',
    keywords: ['youtube thumbnail downloader', 'download youtube thumbnail', 'youtube thumbnail hd', 'get youtube thumbnail']
  },
  {
    id: '10',
    name: 'TikTok Video Downloader',
    description: 'Download TikTok videos without watermark. Fast, free, and unlimited downloads.',
    slug: 'tiktok-video-downloader',
    category: 'downloader-tools',
    icon: 'Video',
    featured: true,
    metaTitle: 'TikTok Video Downloader | Download Without Watermark Free',
    metaDescription: 'Download TikTok videos without watermark for free. Save videos in HD quality. No registration required, unlimited downloads.',
    keywords: ['tiktok downloader', 'download tiktok videos', 'tiktok video download', 'tiktok without watermark', 'save tiktok videos']
  },
  {
    id: '11',
    name: 'Instagram Photo Downloader',
    description: 'Download Instagram photos and images in high quality. Free online tool.',
    slug: 'instagram-photo-downloader',
    category: 'downloader-tools',
    icon: 'Instagram',
    featured: false,
    metaTitle: 'Instagram Photo Downloader | Download Images Free Online',
    metaDescription: 'Download Instagram photos in high quality for free. Save images from posts easily. Fast, secure, and unlimited downloads.',
    keywords: ['instagram downloader', 'download instagram photos', 'instagram image downloader', 'save instagram photos']
  }
];

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: '10 Best Free Online Tools for Content Creators in 2024',
    slug: 'best-free-online-tools-content-creators-2024',
    excerpt: 'Discover the essential free tools every content creator needs for image editing, video processing, and productivity.',
    content: `Content creation has never been more accessible, thanks to the plethora of free online tools available. Whether you're a YouTuber, blogger, or social media influencer, having the right tools can significantly improve your workflow and output quality.

## Image Optimization Tools

One of the most crucial aspects of content creation is image optimization. Large image files can slow down your website and affect user experience. Our Image Compressor tool helps you reduce file sizes without compromising quality, making it perfect for web use.

## Video Content Tools

For video creators, having access to tools like our YouTube Thumbnail Downloader and TikTok Video Downloader can save hours of work. These tools allow you to repurpose content and study successful thumbnails in your niche.

## Security and Productivity

Don't forget about security! Our Password Generator helps you create strong, unique passwords for all your accounts, protecting your valuable content and personal information.

## Text and Writing Tools

For writers and bloggers, our Word Counter and Text Case Converter tools streamline the editing process, ensuring your content meets platform requirements and maintains professional formatting.

Start using these free tools today and take your content creation to the next level!`,
    author: 'SmartToolsHub Team',
    date: '2024-01-15',
    category: 'Productivity',
    tags: ['content creation', 'free tools', 'productivity', 'online tools'],
    featured: true
  },
  {
    id: '2',
    title: 'How to Compress Images Without Losing Quality',
    slug: 'compress-images-without-losing-quality',
    excerpt: 'Learn the best practices for image compression and how to maintain quality while reducing file size.',
    content: `Image compression is essential for website performance, but many creators worry about losing quality. This guide will show you how to compress images effectively while maintaining visual fidelity.

## Understanding Image Compression

Image compression works by removing redundant data from image files. There are two types:
- **Lossless compression**: Reduces file size without losing quality
- **Lossy compression**: Achieves smaller files by slightly reducing quality

## Best Practices

1. **Choose the right format**: Use JPG for photographs, PNG for graphics with transparency, and WebP for modern browsers
2. **Find the balance**: Aim for the smallest file size that still looks good
3. **Batch process**: Compress multiple images at once to save time

## Using Our Image Compressor

Our free Image Compressor tool makes it easy to optimize your images. Simply upload your files, adjust the compression settings, and download the optimized versions. The tool supports JPG, PNG, and WebP formats.

Start compressing your images today and improve your website's loading speed!`,
    author: 'SmartToolsHub Team',
    date: '2024-01-10',
    category: 'Tutorial',
    tags: ['image compression', 'optimization', 'web performance', 'tutorial'],
    featured: true
  },
  {
    id: '3',
    title: 'The Ultimate Guide to Creating Strong Passwords',
    slug: 'ultimate-guide-creating-strong-passwords',
    excerpt: 'Protect your online accounts with these expert tips for creating and managing secure passwords.',
    content: `In today's digital world, password security is more important than ever. With data breaches becoming increasingly common, creating strong, unique passwords is essential for protecting your personal and professional accounts.

## What Makes a Password Strong?

A strong password should have:
- At least 12 characters
- A mix of uppercase and lowercase letters
- Numbers and special characters
- No personal information
- No common words or patterns

## The Problem with Weak Passwords

Weak passwords can be cracked in seconds using modern computing power. Common passwords like "123456" or "password" offer virtually no protection against attackers.

## Using a Password Generator

Our Password Generator creates cryptographically secure passwords that are virtually impossible to crack. You can customize:
- Password length
- Character types (uppercase, lowercase, numbers, symbols)
- Exclusion of similar characters

## Password Management Tips

1. Use a unique password for each account
2. Enable two-factor authentication when available
3. Consider using a password manager
4. Change passwords periodically
5. Never share passwords via email or messaging apps

Protect your accounts today by generating strong passwords with our free tool!`,
    author: 'SmartToolsHub Team',
    date: '2024-01-05',
    category: 'Security',
    tags: ['password security', 'cybersecurity', 'online safety', 'strong passwords'],
    featured: false
  },
  {
    id: '4',
    title: 'How to Download YouTube Thumbnails in HD Quality',
    slug: 'download-youtube-thumbnails-hd-quality',
    excerpt: 'Step-by-step guide to downloading high-quality thumbnails from any YouTube video.',
    content: `YouTube thumbnails are crucial for video success, and sometimes you need to download them for analysis, inspiration, or other purposes. This guide shows you how to get YouTube thumbnails in the highest quality available.

## Why Download YouTube Thumbnails?

- **Competitor analysis**: Study successful thumbnails in your niche
- **Inspiration**: Learn from top creators' design choices
- **Archiving**: Save thumbnails for reference or portfolio
- **Research**: Analyze trends and patterns

## Available Thumbnail Resolutions

YouTube stores thumbnails in multiple resolutions:
- **Default**: 120x90 pixels
- **Medium**: 320x180 pixels
- **High**: 480x360 pixels
- **Standard**: 640x480 pixels
- **Max Resolution**: 1280x720 pixels (HD)

## Using Our Thumbnail Downloader

Our YouTube Thumbnail Downloader makes it easy to get thumbnails in all available resolutions:

1. Copy the YouTube video URL
2. Paste it into our tool
3. Preview all available thumbnail sizes
4. Download the resolution you need

The tool works with any public YouTube video and provides instant access to all thumbnail variations.

## Best Practices

- Always respect copyright and use thumbnails responsibly
- Don't reuse others' thumbnails without permission
- Use downloaded thumbnails for reference and learning only

Start downloading YouTube thumbnails today with our free tool!`,
    author: 'SmartToolsHub Team',
    date: '2023-12-28',
    category: 'Tutorial',
    tags: ['youtube', 'thumbnails', 'video marketing', 'tutorial'],
    featured: false
  },
  {
    id: '5',
    title: 'QR Codes: Everything You Need to Know',
    slug: 'qr-codes-everything-you-need-to-know',
    excerpt: 'Learn how QR codes work, their uses, and how to create them for free.',
    content: `QR codes have become ubiquitous in our daily lives, from restaurant menus to payment systems. This comprehensive guide covers everything you need to know about QR codes and how to use them effectively.

## What Are QR Codes?

QR (Quick Response) codes are two-dimensional barcodes that can store various types of information, including:
- URLs and website links
- Text and contact information
- WiFi credentials
- Email addresses and phone numbers
- Calendar events

## History of QR Codes

QR codes were invented in 1994 by Denso Wave, a Japanese automotive company. Originally used for tracking vehicle parts, they've since found applications across virtually every industry.

## Common Uses

1. **Marketing**: Direct customers to websites, promotions, or social media
2. **Payments**: Enable contactless transactions
3. **Information sharing**: Share contact details or WiFi passwords
4. **Authentication**: Verify tickets, coupons, or identities
5. **Inventory management**: Track products and assets

## Creating QR Codes

Our QR Code Generator makes it easy to create custom QR codes for any purpose:

1. Choose the type of QR code (URL, text, WiFi, etc.)
2. Enter your information
3. Customize the appearance (optional)
4. Download your QR code

## Best Practices

- Test your QR code before printing
- Ensure sufficient contrast for scanning
- Include a call-to-action near the code
- Make the code large enough to scan easily
- Use URL shorteners for cleaner codes

Start creating QR codes today with our free generator!`,
    author: 'SmartToolsHub Team',
    date: '2023-12-20',
    category: 'Guide',
    tags: ['qr codes', 'marketing', 'technology', 'guide'],
    featured: true
  }
];

export const getToolBySlug = (slug: string): Tool | undefined => {
  return tools.find(tool => tool.slug === slug);
};

export const getToolsByCategory = (categorySlug: string): Tool[] => {
  return tools.filter(tool => tool.category === categorySlug);
};

export const getFeaturedTools = (): Tool[] => {
  return tools.filter(tool => tool.featured);
};

export const getBlogPostBySlug = (slug: string): BlogPost | undefined => {
  return blogPosts.find(post => post.slug === slug);
};

export const getFeaturedPosts = (): BlogPost[] => {
  return blogPosts.filter(post => post.featured);
};
