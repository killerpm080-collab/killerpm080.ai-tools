import { useState } from 'react';
import { 
  Lock, 
  LayoutDashboard, 
  Wrench, 
  FileText, 
  BarChart3, 
  Settings,
  LogOut,
  Plus,
  Edit,
  Trash2,
  Eye,
  Search
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SEO } from '@/components/SEO';
import { tools, blogPosts } from '@/data/tools';

export function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [loginError, setLoginError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    // Demo login - in production, this would validate against a backend
    if (loginData.email === 'admin@smarttoolshub.com' && loginData.password === 'admin') {
      setIsLoggedIn(true);
    } else {
      setLoginError('Invalid credentials. Try admin@smarttoolshub.com / admin');
    }
  };

  if (!isLoggedIn) {
    return (
      <>
        <SEO
          title="Admin Login - SmartToolsHub"
          description="Admin dashboard login for SmartToolsHub."
          noIndex
        />
        <div className="min-h-screen flex items-center justify-center bg-gray-100 py-12">
          <div className="w-full max-w-md">
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-8 h-8 text-white" />
                  </div>
                  <h1 className="text-2xl font-bold">Admin Login</h1>
                  <p className="text-gray-600 text-sm mt-1">
                    Sign in to access the dashboard
                  </p>
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  {loginError && (
                    <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg">
                      {loginError}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <Input
                      type="email"
                      value={loginData.email}
                      onChange={(e) => setLoginData(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="admin@smarttoolshub.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Password</label>
                    <Input
                      type="password"
                      value={loginData.password}
                      onChange={(e) => setLoginData(prev => ({ ...prev, password: e.target.value }))}
                      placeholder="••••••••"
                    />
                  </div>

                  <Button type="submit" className="w-full">
                    <Lock className="w-4 h-4 mr-2" />
                    Sign In
                  </Button>
                </form>

                <p className="text-center text-sm text-gray-500 mt-4">
                  Demo: admin@smarttoolshub.com / admin
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <SEO
        title="Admin Dashboard - SmartToolsHub"
        description="Admin dashboard for managing SmartToolsHub."
        noIndex
      />

      <div className="min-h-screen bg-gray-100">
        {/* Admin Header */}
        <header className="bg-white border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <LayoutDashboard className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold">Admin Dashboard</h1>
              </div>
              <Button variant="outline" onClick={() => setIsLoggedIn(false)}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-8">
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">
                <BarChart3 className="w-4 h-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="tools">
                <Wrench className="w-4 h-4 mr-2" />
                Tools
              </TabsTrigger>
              <TabsTrigger value="blog">
                <FileText className="w-4 h-4 mr-2" />
                Blog
              </TabsTrigger>
              <TabsTrigger value="settings">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-1">Total Tools</p>
                    <p className="text-3xl font-bold">{tools.length}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-1">Blog Posts</p>
                    <p className="text-3xl font-bold">{blogPosts.length}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-1">Monthly Users</p>
                    <p className="text-3xl font-bold">1.2M</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-600 mb-1">Page Views</p>
                    <p className="text-3xl font-bold">5.8M</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Recent Activity</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm">New user registration</span>
                      <span className="text-xs text-gray-500">2 minutes ago</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm">Tool usage: Image Compressor</span>
                      <span className="text-xs text-gray-500">5 minutes ago</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="text-sm">Blog post published</span>
                      <span className="text-xs text-gray-500">1 hour ago</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tools Tab */}
            <TabsContent value="tools">
              <div className="flex items-center justify-between mb-6">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input placeholder="Search tools..." className="pl-10" />
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Tool
                </Button>
              </div>

              <Card>
                <CardContent className="p-0">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="text-left p-4 text-sm font-medium">Name</th>
                        <th className="text-left p-4 text-sm font-medium">Category</th>
                        <th className="text-left p-4 text-sm font-medium">Status</th>
                        <th className="text-right p-4 text-sm font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tools.map((tool) => (
                        <tr key={tool.id} className="border-b last:border-0">
                          <td className="p-4">
                            <p className="font-medium">{tool.name}</p>
                            <p className="text-sm text-gray-500">/{tool.slug}</p>
                          </td>
                          <td className="p-4">
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              {tool.category}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-green-600 bg-green-50 px-2 py-1 rounded">
                              Active
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Blog Tab */}
            <TabsContent value="blog">
              <div className="flex items-center justify-between mb-6">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input placeholder="Search posts..." className="pl-10" />
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  New Post
                </Button>
              </div>

              <Card>
                <CardContent className="p-0">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="text-left p-4 text-sm font-medium">Title</th>
                        <th className="text-left p-4 text-sm font-medium">Category</th>
                        <th className="text-left p-4 text-sm font-medium">Date</th>
                        <th className="text-right p-4 text-sm font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {blogPosts.map((post) => (
                        <tr key={post.id} className="border-b last:border-0">
                          <td className="p-4">
                            <p className="font-medium">{post.title}</p>
                            <p className="text-sm text-gray-500">/{post.slug}</p>
                          </td>
                          <td className="p-4">
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              {post.category}
                            </span>
                          </td>
                          <td className="p-4 text-sm">{post.date}</td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Site Settings</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Site Name</label>
                      <Input defaultValue="SmartToolsHub" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Site Description</label>
                      <Input defaultValue="Free Online Tools for Everyone" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Contact Email</label>
                      <Input defaultValue="support@smarttoolshub.com" />
                    </div>
                    <Button>Save Changes</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}

export default AdminPage;
