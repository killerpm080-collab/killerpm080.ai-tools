import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, User, Tag, Share2, Twitter, Facebook, Linkedin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { SEO } from '@/components/SEO';
import { getBlogPostBySlug, blogPosts } from '@/data/tools';
import { generateArticleSchema, generateBreadcrumbSchema } from '@/lib/utils';
import { AdPlacement } from '@/components/AdPlacement';

export function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const post = slug ? getBlogPostBySlug(slug) : undefined;

  if (!post) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Article Not Found</h1>
        <p className="text-gray-600 mb-6">The article you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/blog">Browse All Articles</Link>
        </Button>
      </div>
    );
  }

  const relatedPosts = blogPosts
    .filter(p => p.category === post.category && p.id !== post.id)
    .slice(0, 3);

  const schemas = [
    generateArticleSchema(
      post.title,
      post.excerpt,
      `https://smarttoolshub.com/blog/${post.slug}`,
      post.author,
      post.date
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Blog', url: 'https://smarttoolshub.com/blog' },
      { name: post.title, url: `https://smarttoolshub.com/blog/${post.slug}` }
    ])
  ];

  const shareUrl = `https://smarttoolshub.com/blog/${post.slug}`;
  const shareText = encodeURIComponent(post.title);

  return (
    <>
      <SEO
        title={`${post.title} - SmartToolsHub Blog`}
        description={post.excerpt}
        keywords={post.tags}
        canonical={`https://smarttoolshub.com/blog/${post.slug}`}
        schema={schemas}
      />

      {/* Breadcrumb */}
      <div className="bg-gray-100 border-b">
        <div className="container mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-sm text-gray-600">
            <Link to="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <Link to="/blog" className="hover:text-blue-600">Blog</Link>
            <span>/</span>
            <span className="text-gray-900 truncate max-w-[200px]">{post.title}</span>
          </nav>
        </div>
      </div>

      {/* Article Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Button asChild variant="outline" className="mb-4 border-white text-white hover:bg-white/10">
              <Link to="/blog">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Blog
              </Link>
            </Button>
            <span className="inline-block bg-white/20 backdrop-blur-sm rounded-full px-3 py-1 text-sm mb-4">
              {post.category}
            </span>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{post.title}</h1>
            <div className="flex flex-wrap items-center gap-4 text-white/80">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {post.date}
              </span>
              <span className="flex items-center gap-1">
                <User className="w-4 h-4" />
                {post.author}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Article Content */}
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-6 md:p-8">
                  {/* Article Body */}
                  <article className="prose prose-lg max-w-none">
                    {post.content.split('\n\n').map((paragraph, index) => {
                      if (paragraph.startsWith('## ')) {
                        return <h2 key={index} className="text-2xl font-bold mt-8 mb-4">{paragraph.replace('## ', '')}</h2>;
                      }
                      if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                        return <p key={index} className="font-bold">{paragraph.replace(/\*\*/g, '')}</p>;
                      }
                      if (paragraph.startsWith('- ')) {
                        return (
                          <ul key={index} className="list-disc pl-6 mb-4">
                            {paragraph.split('\n').map((item, i) => (
                              <li key={i}>{item.replace('- ', '')}</li>
                            ))}
                          </ul>
                        );
                      }
                      if (paragraph.match(/^\d+\./)) {
                        return (
                          <ol key={index} className="list-decimal pl-6 mb-4">
                            {paragraph.split('\n').map((item, i) => (
                              <li key={i}>{item.replace(/^\d+\.\s*/, '')}</li>
                            ))}
                          </ol>
                        );
                      }
                      return <p key={index} className="mb-4 leading-relaxed">{paragraph}</p>;
                    })}
                  </article>

                  {/* Tags */}
                  <div className="mt-8 pt-6 border-t">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Tag className="w-4 h-4 text-gray-500" />
                      {post.tags.map((tag) => (
                        <span 
                          key={tag}
                          className="text-sm bg-gray-100 text-gray-600 px-3 py-1 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Share */}
                  <div className="mt-6 pt-6 border-t">
                    <p className="text-sm text-gray-600 mb-3 flex items-center gap-2">
                      <Share2 className="w-4 h-4" />
                      Share this article
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" asChild>
                        <a 
                          href={`https://twitter.com/intent/tweet?url=${shareUrl}&text=${shareText}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Twitter className="w-4 h-4 mr-2" />
                          Twitter
                        </a>
                      </Button>
                      <Button variant="outline" size="sm" asChild>
                        <a 
                          href={`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Facebook className="w-4 h-4 mr-2" />
                          Facebook
                        </a>
                      </Button>
                      <Button variant="outline" size="sm" asChild>
                        <a 
                          href={`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Linkedin className="w-4 h-4 mr-2" />
                          LinkedIn
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* In-Content Ad */}
              <div className="mt-6">
                <AdPlacement location="in-content" />
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Sidebar Ad */}
              <AdPlacement location="sidebar" />

              {/* Related Articles */}
              {relatedPosts.length > 0 && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-4">Related Articles</h3>
                    <div className="space-y-4">
                      {relatedPosts.map((relatedPost) => (
                        <Link
                          key={relatedPost.id}
                          to={`/blog/${relatedPost.slug}`}
                          className="block p-3 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <p className="font-medium text-sm mb-1">{relatedPost.title}</p>
                          <p className="text-xs text-gray-500">{relatedPost.date}</p>
                        </Link>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Categories */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-4">Categories</h3>
                  <div className="space-y-2">
                    {Array.from(new Set(blogPosts.map(p => p.category))).map((category) => (
                      <Link
                        key={category}
                        to={`/blog?category=${category.toLowerCase()}`}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <span className="text-sm">{category}</span>
                        <span className="text-xs text-gray-500">
                          {blogPosts.filter(p => p.category === category).length}
                        </span>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default BlogPostPage;
