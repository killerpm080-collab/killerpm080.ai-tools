import { Link } from 'react-router-dom';
import { Target, Heart, Zap, Users, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { SEO } from '@/components/SEO';
import { generateWebPageSchema, generateBreadcrumbSchema } from '@/lib/utils';

export function AboutPage() {
  const schemas = [
    generateWebPageSchema(
      'About Us - SmartToolsHub',
      'Learn about SmartToolsHub, our mission to provide free online tools, and the team behind our platform.',
      'https://smarttoolshub.com/about'
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'About', url: 'https://smarttoolshub.com/about' }
    ])
  ];

  return (
    <>
      <SEO
        title="About Us - SmartToolsHub"
        description="Learn about SmartToolsHub, our mission to provide free online tools, and the team behind our platform."
        keywords={['about', 'mission', 'team', 'smarttoolshub', 'online tools']}
        canonical="https://smarttoolshub.com/about"
        schema={schemas}
      />

      {/* Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">About SmartToolsHub</h1>
            <p className="text-white/90 text-lg">
              Empowering everyone with free, accessible online tools
            </p>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              At SmartToolsHub, we believe that everyone should have access to powerful online tools 
              without barriers. Our mission is to provide a comprehensive collection of free, secure, 
              and easy-to-use tools that help people accomplish their daily tasks more efficiently.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed">
              Whether you're a student, professional, content creator, or just someone looking to 
              get things done, our tools are designed with you in mind. No registration required, 
              no hidden fees, and no compromises on quality.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Free Forever</h3>
                <p className="text-gray-600 text-sm">
                  All our tools are completely free to use with no hidden costs or premium features.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Fast & Efficient</h3>
                <p className="text-gray-600 text-sm">
                  Our tools work instantly in your browser with no waiting or delays.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Privacy First</h3>
                <p className="text-gray-600 text-sm">
                  Your data never leaves your browser. We don't store or track anything.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">User Focused</h3>
                <p className="text-gray-600 text-sm">
                  We design our tools with real users in mind, focusing on simplicity and usability.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl font-bold text-blue-600 mb-2">50+</p>
              <p className="text-gray-600">Free Tools</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-green-600 mb-2">1M+</p>
              <p className="text-gray-600">Monthly Users</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-purple-600 mb-2">10M+</p>
              <p className="text-gray-600">Tasks Completed</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-orange-600 mb-2">99.9%</p>
              <p className="text-gray-600">Uptime</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Try Our Tools?
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Explore our collection of free online tools and see how they can help you.
          </p>
          <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            <Link to="/tools">
              Explore All Tools
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}

export default AboutPage;
