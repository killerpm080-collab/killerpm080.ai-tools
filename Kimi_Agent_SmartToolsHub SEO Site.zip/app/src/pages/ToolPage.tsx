import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Wrench, Star, Clock, Shield, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { SEO } from '@/components/SEO';
import { getToolBySlug, tools, categories } from '@/data/tools';
import { generateSoftwareApplicationSchema, generateBreadcrumbSchema, generateFAQSchema } from '@/lib/utils';
import { AdPlacement, InToolAd } from '@/components/AdPlacement';

// Import all tool components
import { ImageCompressor } from '@/components/tools/ImageCompressor';
import { PngToJpgConverter } from '@/components/tools/PngToJpgConverter';
import { JpgToPngConverter } from '@/components/tools/JpgToPngConverter';
import { ImageResizer } from '@/components/tools/ImageResizer';
import { PasswordGenerator } from '@/components/tools/PasswordGenerator';
import { WordCounter } from '@/components/tools/WordCounter';
import { TextCaseConverter } from '@/components/tools/TextCaseConverter';
import { QrCodeGenerator } from '@/components/tools/QrCodeGenerator';
import { YoutubeThumbnailDownloader } from '@/components/tools/YoutubeThumbnailDownloader';
import { TiktokVideoDownloader } from '@/components/tools/TiktokVideoDownloader';
import { InstagramPhotoDownloader } from '@/components/tools/InstagramPhotoDownloader';

const toolComponents: Record<string, React.ComponentType> = {
  'image-compressor': ImageCompressor,
  'png-to-jpg-converter': PngToJpgConverter,
  'jpg-to-png-converter': JpgToPngConverter,
  'image-resizer': ImageResizer,
  'password-generator': PasswordGenerator,
  'word-counter': WordCounter,
  'text-case-converter': TextCaseConverter,
  'qr-code-generator': QrCodeGenerator,
  'youtube-thumbnail-downloader': YoutubeThumbnailDownloader,
  'tiktok-video-downloader': TiktokVideoDownloader,
  'instagram-photo-downloader': InstagramPhotoDownloader,
};

const toolFAQs: Record<string, { question: string; answer: string }[]> = {
  'image-compressor': [
    {
      question: 'Is this image compressor free to use?',
      answer: 'Yes, our image compressor is completely free to use with no limits on the number of images you can compress.'
    },
    {
      question: 'Will compressing reduce image quality?',
      answer: 'Our smart compression algorithm reduces file size while maintaining the best possible visual quality. You can adjust the quality slider to find the perfect balance.'
    },
    {
      question: 'Is my data secure?',
      answer: 'Absolutely! All image processing happens in your browser. Your images are never uploaded to our servers.'
    }
  ],
  'password-generator': [
    {
      question: 'Are the generated passwords secure?',
      answer: 'Yes, we use cryptographically secure random number generation to create passwords that are virtually impossible to predict or crack.'
    },
    {
      question: 'Do you store the passwords?',
      answer: 'No, all passwords are generated locally in your browser. We never see or store any passwords you generate.'
    },
    {
      question: 'What makes a strong password?',
      answer: 'A strong password should be at least 12 characters long and include a mix of uppercase, lowercase, numbers, and special characters.'
    }
  ],
  'qr-code-generator': [
    {
      question: 'Are the QR codes free?',
      answer: 'Yes, you can generate unlimited QR codes for free with no registration required.'
    },
    {
      question: 'Do the QR codes expire?',
      answer: 'No, the QR codes you generate are permanent and will work forever as long as the linked content remains accessible.'
    },
    {
      question: 'What can I encode in a QR code?',
      answer: 'You can encode URLs, text, WiFi credentials, email addresses, phone numbers, and more.'
    }
  ]
};

export function ToolPage() {
  const { slug } = useParams<{ slug: string }>();
  const tool = slug ? getToolBySlug(slug) : undefined;

  if (!tool) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Tool Not Found</h1>
        <p className="text-gray-600 mb-6">The tool you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/tools">Browse All Tools</Link>
        </Button>
      </div>
    );
  }

  const ToolComponent = toolComponents[tool.slug];
  const category = categories.find(c => c.slug === tool.category);
  const relatedTools = tools
    .filter(t => t.category === tool.category && t.id !== tool.id)
    .slice(0, 3);

  const faqs = toolFAQs[tool.slug] || [
    {
      question: `Is the ${tool.name} free to use?`,
      answer: 'Yes, this tool is completely free to use with no registration required.'
    },
    {
      question: 'Is my data secure?',
      answer: 'Yes, all processing happens in your browser. Your data is never uploaded to our servers.'
    },
    {
      question: 'What devices are supported?',
      answer: 'Our tools work on all modern browsers including Chrome, Firefox, Safari, and Edge on desktop and mobile devices.'
    }
  ];

  const schemas = [
    generateSoftwareApplicationSchema(
      tool.name,
      tool.description,
      `https://smarttoolshub.com/tool/${tool.slug}`,
      'UtilitiesApplication'
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Tools', url: 'https://smarttoolshub.com/tools' },
      { name: tool.name, url: `https://smarttoolshub.com/tool/${tool.slug}` }
    ]),
    generateFAQSchema(faqs)
  ];

  return (
    <>
      <SEO
        title={tool.metaTitle}
        description={tool.metaDescription}
        keywords={tool.keywords}
        canonical={`https://smarttoolshub.com/tool/${tool.slug}`}
        schema={schemas}
      />

      {/* Breadcrumb */}
      <div className="bg-gray-100 border-b">
        <div className="container mx-auto px-4 py-3">
          <nav className="flex items-center gap-2 text-sm text-gray-600">
            <Link to="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <Link to="/tools" className="hover:text-blue-600">Tools</Link>
            <span>/</span>
            {category && (
              <>
                <Link to={`/category/${category.slug}`} className="hover:text-blue-600">
                  {category.name}
                </Link>
                <span>/</span>
              </>
            )}
            <span className="text-gray-900">{tool.name}</span>
          </nav>
        </div>
      </div>

      {/* Tool Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Button asChild variant="outline" className="mb-4 border-white text-white hover:bg-white/10">
              <Link to="/tools">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Tools
              </Link>
            </Button>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{tool.name}</h1>
            <p className="text-white/90 text-lg">{tool.description}</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Tool Area */}
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="p-6">
                  {ToolComponent ? <ToolComponent /> : (
                    <div className="text-center py-12">
                      <Wrench className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-600">Tool component coming soon</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* In-Tool Ad */}
              <InToolAd />

              {/* FAQ Section */}
              <Card className="mt-8">
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-6">Frequently Asked Questions</h2>
                  <div className="space-y-4">
                    {faqs.map((faq, index) => (
                      <div key={index} className="border-b last:border-0 pb-4 last:pb-0">
                        <h3 className="font-medium mb-2">{faq.question}</h3>
                        <p className="text-gray-600 text-sm">{faq.answer}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Sidebar Ad */}
              <AdPlacement location="sidebar" />

              {/* Tool Info */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-4">Tool Information</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span>Free to use</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-500" />
                      <span>Instant results</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-green-500" />
                      <span>Secure & private</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Related Tools */}
              {relatedTools.length > 0 && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-4">Related Tools</h3>
                    <div className="space-y-3">
                      {relatedTools.map((relatedTool) => (
                        <Link
                          key={relatedTool.id}
                          to={`/tool/${relatedTool.slug}`}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Wrench className="w-4 h-4 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">{relatedTool.name}</p>
                            <p className="text-xs text-gray-500 line-clamp-1">
                              {relatedTool.description}
                            </p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Category Link */}
              {category && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2">Category</h3>
                    <Link 
                      to={`/category/${category.slug}`}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <span>{category.name}</span>
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </Link>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default ToolPage;
