import { Link } from 'react-router-dom';
import { 
  ArrowRight, 
  Zap, 
  Shield, 
  Clock, 
  Star,
  Sparkles,
  Wrench
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { SEO } from '@/components/SEO';
import { categories, getFeaturedTools } from '@/data/tools';
import { generateWebPageSchema, generateSoftwareApplicationSchema } from '@/lib/utils';
import { AdPlacement } from '@/components/AdPlacement';

export function HomePage() {
  const featuredTools = getFeaturedTools();

  const schemas = [
    generateWebPageSchema(
      'SmartToolsHub - Free Online Tools for Everyone',
      'Discover 50+ free online tools including image compressors, password generators, QR code creators, and more. Fast, secure, and easy to use.',
      'https://smarttoolshub.com/'
    ),
    ...featuredTools.slice(0, 3).map(tool => 
      generateSoftwareApplicationSchema(
        tool.name,
        tool.description,
        `https://smarttoolshub.com/tool/${tool.slug}`,
        'UtilitiesApplication'
      )
    )
  ];

  return (
    <>
      <SEO
        title="SmartToolsHub - Free Online Tools for Everyone"
        description="Discover 50+ free online tools including image compressors, password generators, QR code creators, and more. Fast, secure, and easy to use."
        keywords={[
          'free online tools',
          'image compressor',
          'password generator',
          'qr code generator',
          'youtube downloader',
          'text tools',
          'online utilities'
        ]}
        canonical="https://smarttoolshub.com/"
        schema={schemas}
      />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">100% Free - No Registration Required</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Free Online Tools for{' '}
              <span className="text-yellow-300">Everyone</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
              Compress images, generate passwords, create QR codes, download videos, 
              and more. All tools are free, secure, and work instantly in your browser.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                <Link to="/tools">
                  Explore All Tools
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Link to="/tool/image-compressor">
                  Try Image Compressor
                </Link>
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mt-12 max-w-2xl mx-auto">
              <div>
                <p className="text-3xl md:text-4xl font-bold">50+</p>
                <p className="text-white/80 text-sm">Free Tools</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold">1M+</p>
                <p className="text-white/80 text-sm">Monthly Users</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold">100%</p>
                <p className="text-white/80 text-sm">Free to Use</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Tools Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Popular Tools</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our most popular tools used by millions of people every month
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredTools.map((tool) => (
              <Card key={tool.id} className="group hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1 group-hover:text-blue-600 transition-colors">
                        {tool.name}
                      </h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {tool.description}
                      </p>
                      <Button asChild variant="outline" size="sm" className="w-full">
                        <Link to={`/tool/${tool.slug}`}>
                          Use Tool
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button asChild variant="outline" size="lg">
              <Link to="/tools">
                View All Tools
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Browse by Category</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Find the right tool for your needs from our organized categories
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {categories.map((category) => (
              <Link 
                key={category.id} 
                to={`/category/${category.slug}`}
                className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow group"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600 transition-colors">
                  <Wrench className="w-6 h-6 text-blue-600 group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-semibold mb-2">{category.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{category.toolCount} tools</p>
                <span className="text-blue-600 text-sm font-medium group-hover:underline">
                  Explore →
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Sidebar Ad Section */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="flex justify-center">
            <AdPlacement location="sidebar" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose SmartToolsHub?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We're committed to providing the best free online tools experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Lightning Fast</h3>
                <p className="text-gray-600 text-sm">
                  All tools work instantly in your browser. No waiting, no delays.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">100% Secure</h3>
                <p className="text-gray-600 text-sm">
                  Your files never leave your browser. We don't store any data.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Always Free</h3>
                <p className="text-gray-600 text-sm">
                  No hidden fees, no registration required. Free forever.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">High Quality</h3>
                <p className="text-gray-600 text-sm">
                  Professional-grade tools with no quality loss.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Join millions of users who trust SmartToolsHub for their daily online tool needs.
          </p>
          <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            <Link to="/tools">
              Explore All Tools
              <ArrowRight className="w-5 h-5 ml-2" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}

export default HomePage;
