import { Shield, Lock, Eye, Server, Cookie } from 'lucide-react';
import { SEO } from '@/components/SEO';
import { generateWebPageSchema, generateBreadcrumbSchema } from '@/lib/utils';

export function PrivacyPage() {
  const schemas = [
    generateWebPageSchema(
      'Privacy Policy - SmartToolsHub',
      'Learn how SmartToolsHub protects your privacy. We don\'t collect or store any personal data.',
      'https://smarttoolshub.com/privacy'
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Privacy Policy', url: 'https://smarttoolshub.com/privacy' }
    ])
  ];

  return (
    <>
      <SEO
        title="Privacy Policy - SmartToolsHub"
        description="Learn how SmartToolsHub protects your privacy. We don't collect or store any personal data."
        keywords={['privacy policy', 'data protection', 'privacy', 'smarttoolshub']}
        canonical="https://smarttoolshub.com/privacy"
        schema={schemas}
      />

      {/* Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Privacy Policy</h1>
            <p className="text-white/90 text-lg">
              Your privacy is our top priority
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Introduction */}
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold">Our Commitment to Privacy</h2>
              </div>
              <p className="text-gray-600 leading-relaxed">
                At SmartToolsHub, we take your privacy seriously. This Privacy Policy explains 
                how we handle your data when you use our website and services. Our core principle 
                is simple: <strong>we don't collect or store any of your personal data or files.</strong>
              </p>
            </div>

            {/* Key Points */}
            <div className="space-y-8">
              <div className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Lock className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Browser-Only Processing</h3>
                    <p className="text-gray-600 leading-relaxed">
                      All our tools process your data directly in your web browser. When you 
                      compress an image, generate a password, or create a QR code, everything 
                      happens on your device. Your files and data never leave your computer 
                      or get sent to our servers.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Eye className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">No Data Collection</h3>
                    <p className="text-gray-600 leading-relaxed">
                      We do not collect, store, or process any personal information. You can 
                      use all our tools anonymously without creating an account or providing 
                      any personal details.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Server className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">No Server Storage</h3>
                    <p className="text-gray-600 leading-relaxed">
                      We don't have databases to store your files or data. Once you close 
                      your browser or navigate away from a tool, any data you processed is 
                      immediately gone. We have no way to access or retrieve it.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Cookie className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">Cookies & Analytics</h3>
                    <p className="text-gray-600 leading-relaxed">
                      We use minimal cookies only for essential website functionality. 
                      We may use anonymous analytics to understand how our tools are used, 
                      but this data cannot identify you personally. You can disable cookies 
                      in your browser settings if you prefer.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Third Party Services */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-4">Third-Party Services</h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                Our website may display advertisements through third-party ad networks. 
                These services may use cookies to show relevant ads. You can learn more 
                about how to opt out of personalized advertising by visiting the 
                <a href="https://www.networkadvertising.org/choices/" className="text-blue-600 hover:underline ml-1" target="_blank" rel="noopener noreferrer">
                  Network Advertising Initiative
                </a>.
              </p>
            </div>

            {/* Changes */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-4">Changes to This Policy</h2>
              <p className="text-gray-600 leading-relaxed">
                We may update this Privacy Policy from time to time. Any changes will be 
                posted on this page with an updated revision date. We encourage you to 
                review this policy periodically.
              </p>
            </div>

            {/* Contact */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
              <p className="text-gray-600 leading-relaxed">
                If you have any questions about this Privacy Policy, please contact us at{' '}
                <a href="mailto:privacy@smarttoolshub.com" className="text-blue-600 hover:underline">
                  privacy@smarttoolshub.com
                </a>.
              </p>
            </div>

            {/* Last Updated */}
            <div className="mt-12 pt-8 border-t">
              <p className="text-sm text-gray-500">
                Last updated: January 1, 2024
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default PrivacyPage;
