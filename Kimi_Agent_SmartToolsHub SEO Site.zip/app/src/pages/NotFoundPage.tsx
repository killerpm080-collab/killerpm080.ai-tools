import { Link } from 'react-router-dom';
import { Home, Search, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SEO } from '@/components/SEO';

export function NotFoundPage() {
  return (
    <>
      <SEO
        title="Page Not Found - SmartToolsHub"
        description="The page you're looking for doesn't exist. Browse our free online tools or go back to the homepage."
        noIndex
      />

      <div className="min-h-[70vh] flex items-center justify-center py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-lg mx-auto text-center">
            {/* 404 Illustration */}
            <div className="mb-8">
              <div className="w-32 h-32 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-16 h-16 text-blue-600" />
              </div>
              <h1 className="text-6xl font-bold text-gray-900 mb-2">404</h1>
              <p className="text-xl text-gray-600">Page Not Found</p>
            </div>

            {/* Message */}
            <p className="text-gray-600 mb-8">
              Oops! The page you're looking for doesn't exist. It might have been moved, 
              deleted, or you may have entered the wrong URL.
            </p>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <Link to="/">
                  <Home className="w-5 h-5 mr-2" />
                  Go Home
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/tools">
                  <Search className="w-5 h-5 mr-2" />
                  Browse Tools
                </Link>
              </Button>
            </div>

            {/* Back Button */}
            <div className="mt-8">
              <Button 
                variant="ghost" 
                onClick={() => window.history.back()}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Go Back
              </Button>
            </div>

            {/* Suggestions */}
            <div className="mt-12 pt-8 border-t">
              <p className="text-sm text-gray-500 mb-4">Popular Pages</p>
              <div className="flex flex-wrap justify-center gap-2">
                <Button asChild variant="outline" size="sm">
                  <Link to="/tool/image-compressor">Image Compressor</Link>
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to="/tool/password-generator">Password Generator</Link>
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to="/tool/qr-code-generator">QR Code Generator</Link>
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to="/blog">Blog</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default NotFoundPage;
