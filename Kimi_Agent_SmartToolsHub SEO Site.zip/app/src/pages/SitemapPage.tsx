import { Link } from 'react-router-dom';
import { Map, Wrench, FileText, Info, Mail, Shield, FileCheck } from 'lucide-react';
import { SEO } from '@/components/SEO';
import { tools, categories, blogPosts } from '@/data/tools';
import { generateWebPageSchema, generateBreadcrumbSchema } from '@/lib/utils';

export function SitemapPage() {
  const schemas = [
    generateWebPageSchema(
      'Sitemap - SmartToolsHub',
      'Complete sitemap of SmartToolsHub. Find all our free online tools, blog posts, and pages.',
      'https://smarttoolshub.com/sitemap'
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Sitemap', url: 'https://smarttoolshub.com/sitemap' }
    ])
  ];

  return (
    <>
      <SEO
        title="Sitemap - SmartToolsHub"
        description="Complete sitemap of SmartToolsHub. Find all our free online tools, blog posts, and pages."
        canonical="https://smarttoolshub.com/sitemap"
        schema={schemas}
      />

      {/* Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Sitemap</h1>
            <p className="text-white/90 text-lg">
              Find everything on SmartToolsHub
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Main Pages */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Map className="w-5 h-5 text-blue-600" />
                <h2 className="text-xl font-bold">Main Pages</h2>
              </div>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                    Home
                  </Link>
                </li>
                <li>
                  <Link to="/tools" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                    All Tools
                  </Link>
                </li>
                <li>
                  <Link to="/blog" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                    Blog
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    About Us
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            {/* Categories */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Wrench className="w-5 h-5 text-green-600" />
                <h2 className="text-xl font-bold">Categories</h2>
              </div>
              <ul className="space-y-2">
                {categories.map((category) => (
                  <li key={category.id}>
                    <Link 
                      to={`/category/${category.slug}`} 
                      className="text-gray-600 hover:text-blue-600 flex items-center gap-2"
                    >
                      <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                      {category.name}
                      <span className="text-xs text-gray-400">({category.toolCount})</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* All Tools */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Wrench className="w-5 h-5 text-purple-600" />
                <h2 className="text-xl font-bold">All Tools ({tools.length})</h2>
              </div>
              <ul className="space-y-2 max-h-80 overflow-y-auto">
                {tools.map((tool) => (
                  <li key={tool.id}>
                    <Link 
                      to={`/tool/${tool.slug}`} 
                      className="text-gray-600 hover:text-blue-600 flex items-center gap-2 text-sm"
                    >
                      <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                      {tool.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Blog Posts */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <FileText className="w-5 h-5 text-orange-600" />
                <h2 className="text-xl font-bold">Blog Posts</h2>
              </div>
              <ul className="space-y-2">
                {blogPosts.map((post) => (
                  <li key={post.id}>
                    <Link 
                      to={`/blog/${post.slug}`} 
                      className="text-gray-600 hover:text-blue-600 flex items-center gap-2 text-sm"
                    >
                      <span className="w-2 h-2 bg-orange-400 rounded-full"></span>
                      {post.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal Pages */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-red-600" />
                <h2 className="text-xl font-bold">Legal Pages</h2>
              </div>
              <ul className="space-y-2">
                <li>
                  <Link to="/privacy" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link to="/terms" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <FileCheck className="w-4 h-4" />
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link to="/sitemap" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                    <Map className="w-4 h-4" />
                    Sitemap
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default SitemapPage;
