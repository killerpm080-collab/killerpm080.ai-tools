import { FileText, Scale, AlertTriangle, CheckCircle } from 'lucide-react';
import { SEO } from '@/components/SEO';
import { generateWebPageSchema, generateBreadcrumbSchema } from '@/lib/utils';

export function TermsPage() {
  const schemas = [
    generateWebPageSchema(
      'Terms of Service - SmartToolsHub',
      'Read the Terms of Service for using SmartToolsHub and our free online tools.',
      'https://smarttoolshub.com/terms'
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Terms of Service', url: 'https://smarttoolshub.com/terms' }
    ])
  ];

  return (
    <>
      <SEO
        title="Terms of Service - SmartToolsHub"
        description="Read the Terms of Service for using SmartToolsHub and our free online tools."
        keywords={['terms of service', 'terms', 'conditions', 'smarttoolshub']}
        canonical="https://smarttoolshub.com/terms"
        schema={schemas}
      />

      {/* Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Terms of Service</h1>
            <p className="text-white/90 text-lg">
              Please read these terms carefully before using our services
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            {/* Introduction */}
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold">Agreement to Terms</h2>
              </div>
              <p className="text-gray-600 leading-relaxed">
                By accessing or using SmartToolsHub, you agree to be bound by these Terms of Service. 
                If you disagree with any part of these terms, you may not access our website or use 
                our tools.
              </p>
            </div>

            {/* Sections */}
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Use of Our Services
                </h3>
                <div className="text-gray-600 leading-relaxed space-y-2">
                  <p>
                    SmartToolsHub provides free online tools for personal and commercial use. 
                    You may use our tools for any lawful purpose, subject to the following restrictions:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>You may not use our tools for any illegal activities</li>
                    <li>You may not attempt to disrupt or damage our services</li>
                    <li>You may not use automated systems to access our tools excessively</li>
                    <li>You are responsible for any content you process using our tools</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                  <Scale className="w-5 h-5 text-blue-600" />
                  Intellectual Property
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  The SmartToolsHub website, including its design, code, and content, is owned by 
                  SmartToolsHub and protected by copyright and other intellectual property laws. 
                  You may not copy, modify, distribute, or create derivative works without our 
                  express permission. However, you retain all rights to any content you process 
                  using our tools.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                  Disclaimer of Warranties
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Our tools are provided "as is" without any warranties, express or implied. 
                  We do not guarantee that our tools will be error-free, secure, or available 
                  at all times. While we strive for accuracy, we cannot guarantee that all 
                  tool outputs will be completely accurate or suitable for your specific needs.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Limitation of Liability</h3>
                <p className="text-gray-600 leading-relaxed">
                  To the maximum extent permitted by law, SmartToolsHub shall not be liable 
                  for any indirect, incidental, special, consequential, or punitive damages 
                  resulting from your use of or inability to use our services. This includes 
                  but is not limited to loss of data, profits, or business opportunities.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">User Content</h3>
                <p className="text-gray-600 leading-relaxed">
                  Any content you upload or process using our tools remains your property. 
                  Since all processing happens in your browser, we never have access to your 
                  content. You are solely responsible for ensuring you have the right to 
                  process any content using our tools.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Third-Party Links</h3>
                <p className="text-gray-600 leading-relaxed">
                  Our website may contain links to third-party websites or services that are 
                  not owned or controlled by SmartToolsHub. We have no control over and assume 
                  no responsibility for the content, privacy policies, or practices of any 
                  third-party websites.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Termination</h3>
                <p className="text-gray-600 leading-relaxed">
                  We reserve the right to terminate or suspend access to our services immediately, 
                  without prior notice or liability, for any reason whatsoever, including without 
                  limitation if you breach these Terms.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Governing Law</h3>
                <p className="text-gray-600 leading-relaxed">
                  These Terms shall be governed by and construed in accordance with the laws 
                  of the United States, without regard to its conflict of law provisions.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Changes to Terms</h3>
                <p className="text-gray-600 leading-relaxed">
                  We reserve the right to modify or replace these Terms at any time. If a 
                  revision is material, we will try to provide at least 30 days' notice prior 
                  to any new terms taking effect. What constitutes a material change will be 
                  determined at our sole discretion.
                </p>
              </div>
            </div>

            {/* Contact */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
              <p className="text-gray-600 leading-relaxed">
                If you have any questions about these Terms, please contact us at{' '}
                <a href="mailto:legal@smarttoolshub.com" className="text-blue-600 hover:underline">
                  legal@smarttoolshub.com
                </a>.
              </p>
            </div>

            {/* Last Updated */}
            <div className="mt-12 pt-8 border-t">
              <p className="text-sm text-gray-500">
                Last updated: January 1, 2024
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default TermsPage;
