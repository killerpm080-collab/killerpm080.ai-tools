import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Wrench, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { SEO } from '@/components/SEO';
import { categories, getToolsByCategory } from '@/data/tools';
import { generateWebPageSchema, generateBreadcrumbSchema } from '@/lib/utils';
import { AdPlacement } from '@/components/AdPlacement';

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const category = categories.find(c => c.slug === slug);
  const tools = slug ? getToolsByCategory(slug) : [];

  if (!category) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Category Not Found</h1>
        <p className="text-gray-600 mb-6">The category you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/tools">Browse All Tools</Link>
        </Button>
      </div>
    );
  }

  const schemas = [
    generateWebPageSchema(
      `${category.name} - Free Online Tools - SmartToolsHub`,
      category.description,
      `https://smarttoolshub.com/category/${category.slug}`
    ),
    generateBreadcrumbSchema([
      { name: 'Home', url: 'https://smarttoolshub.com/' },
      { name: 'Tools', url: 'https://smarttoolshub.com/tools' },
      { name: category.name, url: `https://smarttoolshub.com/category/${category.slug}` }
    ])
  ];

  return (
    <>
      <SEO
        title={`${category.name} - Free Online Tools - SmartToolsHub`}
        description={category.description}
        keywords={[category.name.toLowerCase(), 'online tools', 'free tools', category.slug]}
        canonical={`https://smarttoolshub.com/category/${category.slug}`}
        schema={schemas}
      />

      {/* Header */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Button asChild variant="outline" className="mb-4 border-white text-white hover:bg-white/10">
              <Link to="/tools">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Tools
              </Link>
            </Button>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{category.name}</h1>
            <p className="text-white/90 text-lg">{category.description}</p>
          </div>
        </div>
      </section>

      {/* Ad Placement */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-center">
          <AdPlacement location="in-content" />
        </div>
      </div>

      {/* Tools Grid */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <p className="text-gray-600 mb-6">
            {tools.length} tools in this category
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <Card key={tool.id} className="group hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Wrench className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1 group-hover:text-blue-600 transition-colors">
                        {tool.name}
                      </h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {tool.description}
                      </p>
                      <Button asChild variant="outline" size="sm" className="w-full">
                        <Link to={`/tool/${tool.slug}`}>
                          Use Tool
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {tools.length === 0 && (
            <div className="text-center py-12">
              <Wrench className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No tools yet</h3>
              <p className="text-gray-500">Check back soon for new tools in this category</p>
            </div>
          )}
        </div>
      </section>

      {/* Other Categories */}
      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6">Other Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories
              .filter(c => c.id !== category.id)
              .map((cat) => (
                <Link 
                  key={cat.id} 
                  to={`/category/${cat.slug}`}
                  className="bg-white rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <h3 className="font-medium">{cat.name}</h3>
                  <p className="text-sm text-gray-500">{cat.toolCount} tools</p>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default CategoryPage;
